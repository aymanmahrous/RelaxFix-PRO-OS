import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, InsertCreativeBrief, InsertCinematicScript, InsertScene, InsertBrandKit, InsertExport, creativeBriefs, cinematicScripts, scenes, brandKits, scriptTemplates, exports, projects } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Project queries
 */
export async function createProject(userId: number, title: string, description?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(projects).values({
    userId,
    title,
    description,
    status: "draft",
  });
  
  return result as any;
}

export async function getUserProjects(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(projects).where(eq(projects.userId, userId));
}

export async function getProjectById(projectId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  return result[0];
}

/**
 * Creative Brief queries
 */
export async function createCreativeBrief(briefData: InsertCreativeBrief) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(creativeBriefs).values(briefData);
  return result as any;
}

export async function getCreativeBriefByProject(projectId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(creativeBriefs).where(eq(creativeBriefs.projectId, projectId)).limit(1);
  return result[0];
}

/**
 * Cinematic Script queries
 */
export async function createCinematicScript(scriptData: InsertCinematicScript) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(cinematicScripts).values(scriptData);
  return result as any;
}

export async function getCinematicScriptByProject(projectId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(cinematicScripts).where(eq(cinematicScripts.projectId, projectId)).limit(1);
  return result[0];
}

/**
 * Scene queries
 */
export async function createScene(sceneData: InsertScene) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(scenes).values(sceneData);
  return result as any;
}

export async function getScenesByScript(scriptId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(scenes).where(eq(scenes.scriptId, scriptId)).orderBy(scenes.sequenceOrder);
}

export async function updateScene(sceneId: number, updates: Partial<InsertScene>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.update(scenes).set(updates).where(eq(scenes.id, sceneId));
}

/**
 * Brand Kit queries
 */
export async function createBrandKit(brandKitData: InsertBrandKit) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(brandKits).values(brandKitData);
  return result as any;
}

export async function getUserBrandKits(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(brandKits).where(eq(brandKits.userId, userId));
}

export async function getBrandKitById(brandKitId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(brandKits).where(eq(brandKits.id, brandKitId)).limit(1);
  return result[0];
}

/**
 * Script Template queries
 */
export async function getActiveTemplates() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(scriptTemplates).where(eq(scriptTemplates.isActive, 1));
}

/**
 * Export queries
 */
export async function createExport(exportData: InsertExport) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(exports).values(exportData);
  return result as any;
}

export async function getExportsByScript(scriptId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(exports).where(eq(exports.scriptId, scriptId));
}


