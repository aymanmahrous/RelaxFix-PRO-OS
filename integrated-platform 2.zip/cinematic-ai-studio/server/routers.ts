import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  createProject,
  getUserProjects,
  getProjectById,
  createCreativeBrief,
  getCreativeBriefByProject,
  createCinematicScript,
  getCinematicScriptByProject,
  createScene,
  getScenesByScript,
  updateScene,
  createBrandKit,
  getUserBrandKits,
  getBrandKitById,
  getActiveTemplates,
  createExport,
  getExportsByScript,
} from "./db";
import { invokeLLM } from "./_core/llm";
import { generateImage } from "./_core/imageGeneration";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Projects Router
  projects: router({
    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1, "Title is required"),
        description: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await createProject(ctx.user.id, input.title, input.description);
        return { success: true, projectId: result.insertId };
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserProjects(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ input }) => {
        return getProjectById(input.projectId);
      }),
  }),

  // Creative Brief Router
  creativeBrief: router({
    create: protectedProcedure
      .input(z.object({
        projectId: z.number(),
        serviceType: z.string(),
        city: z.string().optional(),
        tone: z.string(),
        targetAudience: z.string(),
        dialect: z.string(),
        duration: z.number(),
        outputFormat: z.string(),
        additionalNotes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const result = await createCreativeBrief(input);
        return { success: true, briefId: result.insertId };
      }),

    getByProject: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ input }) => {
        return getCreativeBriefByProject(input.projectId);
      }),
  }),

  // Cinematic Script Router with AI Generation
  cinematicScript: router({
    generate: protectedProcedure
      .input(z.object({
        projectId: z.number(),
        briefId: z.number(),
        serviceType: z.string(),
        tone: z.string(),
        targetAudience: z.string(),
        duration: z.number(),
        outputFormat: z.string(),
      }))
      .mutation(async ({ input }) => {
        // Generate script using LLM
        const prompt = `أنت كاتب سيناريو سينمائي احترافي. قم بكتابة سيناريو سينمائي احترافي بناءً على المعلومات التالية:
        
نوع الخدمة: ${input.serviceType}
النبرة: ${input.tone}
الجمهور المستهدف: ${input.targetAudience}
المدة الزمنية: ${input.duration} ثانية
صيغة الإخراج: ${input.outputFormat}

يجب أن يتضمن السيناريو:
1. عنوان جذاب
2. ملخص قصير
3. 3-5 مشاهد واضحة ومنظمة
4. لكل مشهد: الرقم، العنوان، الوصف البصري، الموسيقى/الصوت، المدة الزمنية

الرجاء تقديم الرد بصيغة JSON مع الهيكل التالي:
{
  "title": "عنوان السيناريو",
  "synopsis": "ملخص قصير",
  "scenes": [
    {
      "sceneNumber": 1,
      "title": "عنوان المشهد",
      "prompt": "وصف بصري تفصيلي",
      "duration": 10,
      "voiceLine": "النص الصوتي",
      "cta": "الدعوة للعمل"
    }
  ]
}`;

        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "أنت كاتب سيناريو سينمائي احترافي متخصص في الإعلانات والمحتوى البصري.",
            },
            {
              role: "user",
              content: prompt,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "cinematic_script",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  synopsis: { type: "string" },
                  scenes: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        sceneNumber: { type: "number" },
                        title: { type: "string" },
                        prompt: { type: "string" },
                        duration: { type: "number" },
                        voiceLine: { type: "string" },
                        cta: { type: "string" },
                      },
                      required: ["sceneNumber", "title", "prompt", "duration"],
                    },
                  },
                },
                required: ["title", "synopsis", "scenes"],
                additionalProperties: false,
              },
            },
          },
        });

        const scriptData = JSON.parse(typeof response.choices[0].message.content === 'string' ? response.choices[0].message.content : '');
        const totalDuration = scriptData.scenes.reduce((sum: number, scene: any) => sum + scene.duration, 0);

        // Create script in database
        const scriptResult = await createCinematicScript({
          projectId: input.projectId,
          briefId: input.briefId,
          title: scriptData.title,
          synopsis: scriptData.synopsis,
          totalDuration,
        });

        // Create scenes
        for (const sceneData of scriptData.scenes) {
          const sceneResult = await createScene({
            scriptId: scriptResult.insertId,
            sceneNumber: sceneData.sceneNumber,
            title: sceneData.title,
            prompt: sceneData.prompt,
            duration: sceneData.duration,
            voiceLine: sceneData.voiceLine,
            cta: sceneData.cta,
            sequenceOrder: sceneData.sceneNumber,
          });
        }

        return {
          success: true,
          scriptId: scriptResult.insertId,
          script: scriptData,
        };
      }),

    getByProject: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ input }) => {
        return getCinematicScriptByProject(input.projectId);
      }),
  }),

  // Scenes Router
  scenes: router({
    list: protectedProcedure
      .input(z.object({ scriptId: z.number() }))
      .query(async ({ input }) => {
        return getScenesByScript(input.scriptId);
      }),

    update: protectedProcedure
      .input(z.object({
        sceneId: z.number(),
        cameraAngle: z.string().optional(),
        lensStyle: z.string().optional(),
        lightingStyle: z.string().optional(),
        motionStyle: z.string().optional(),
        voiceLine: z.string().optional(),
        cta: z.string().optional(),
        productTags: z.string().optional(),
        prompt: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { sceneId, ...updates } = input;
        await updateScene(sceneId, updates);
        return { success: true };
      }),

    generateImage: protectedProcedure
      .input(z.object({
        sceneId: z.number(),
        prompt: z.string(),
      }))
      .mutation(async ({ input }) => {
        // Generate reference image using AI
        const { url: imageUrl } = await generateImage({
          prompt: input.prompt,
        });

        // Update scene with image URL
        await updateScene(input.sceneId, {
          referenceImageUrl: imageUrl,
          referenceImagePrompt: input.prompt,
        });

        return { success: true, imageUrl };
      }),
  }),

  // Brand Kit Router
  brandKit: router({
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        description: z.string().optional(),
        logoUrl: z.string().optional(),
        primaryColor: z.string().optional(),
        secondaryColor: z.string().optional(),
        accentColor: z.string().optional(),
        fontFamily: z.string().optional(),
        phoneNumber: z.string().optional(),
        ctaText: z.string().optional(),
        ctaAnimationStyle: z.string().optional(),
        watermarkUrl: z.string().optional(),
        footerLockup: z.string().optional(),
        isDefault: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await createBrandKit({
          userId: ctx.user.id,
          ...input,
        });
        return { success: true, brandKitId: result.insertId };
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserBrandKits(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ brandKitId: z.number() }))
      .query(async ({ input }) => {
        return getBrandKitById(input.brandKitId);
      }),
  }),

  // Templates Router
  templates: router({
    list: publicProcedure.query(async () => {
      return getActiveTemplates();
    }),
  }),

  // Exports Router
  exports: router({
    create: protectedProcedure
      .input(z.object({
        scriptId: z.number(),
        format: z.string(),
        fileUrl: z.string(),
        fileSize: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const result = await createExport(input);
        return { success: true, exportId: result.insertId };
      }),

    getByScript: protectedProcedure
      .input(z.object({ scriptId: z.number() }))
      .query(async ({ input }) => {
        return getExportsByScript(input.scriptId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
