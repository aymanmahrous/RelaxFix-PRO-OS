import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChevronUp, ChevronDown, Image as ImageIcon, Loader2, Film } from "lucide-react";
import { toast } from "sonner";

interface SceneEditorProps {
  scriptId: number;
}

const CAMERA_ANGLES = [
  { value: "drone", label: "طائرة بدون طيار" },
  { value: "macro", label: "عدسة ماكرو" },
  { value: "gimbal", label: "جيمبال" },
  { value: "close-up", label: "لقطة قريبة" },
  { value: "wide", label: "لقطة عريضة" },
  { value: "overhead", label: "من الأعلى" },
];

const LIGHTING_STYLES = [
  { value: "golden_hour", label: "الساعة الذهبية" },
  { value: "cool_blue", label: "أزرق بارد" },
  { value: "luxury_indoor", label: "إضاءة فاخرة داخلية" },
  { value: "dramatic", label: "درامي" },
  { value: "soft_natural", label: "طبيعي ناعم" },
  { value: "neon", label: "نيون" },
];

const MOTION_STYLES = [
  { value: "smooth_pan", label: "حركة سلسة" },
  { value: "dynamic_cut", label: "قطع ديناميكي" },
  { value: "zoom_in", label: "تكبير" },
  { value: "tracking", label: "تتبع" },
  { value: "static", label: "ثابت" },
  { value: "parallax", label: "تأثير المنظور" },
];

export default function SceneEditor({ scriptId }: SceneEditorProps) {
  const [expandedScene, setExpandedScene] = useState<number | null>(null);
  const [editingScene, setEditingScene] = useState<number | null>(null);

  const scenesQuery = trpc.scenes.list.useQuery({ scriptId });
  const updateSceneMutation = trpc.scenes.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث المشهد بنجاح!");
      scenesQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ");
    },
  });

  const generateImageMutation = trpc.scenes.generateImage.useMutation({
    onSuccess: () => {
      toast.success("تم توليد الصورة بنجاح!");
      scenesQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ في توليد الصورة");
    },
  });

  if (scenesQuery.isLoading) {
    return (
      <div className="text-center py-12">
        <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-amber-400"></div>
        <p className="mt-4 text-slate-300">جاري تحميل المشاهد...</p>
      </div>
    );
  }

  const scenes = scenesQuery.data || [];

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-white mb-2">محرر المشاهد</h3>
        <p className="text-slate-300">عدّل كل مشهد وأضف التفاصيل السينمائية</p>
      </div>

      <div className="space-y-4">
        {scenes.map((scene, index) => (
          <Card
            key={scene.id}
            className="bg-slate-800 border-slate-700 hover:border-amber-500/50 transition-colors cursor-pointer"
            onClick={() => setExpandedScene(expandedScene === scene.id ? null : scene.id)}
          >
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-amber-500/20 text-amber-400 font-bold text-sm">
                      {index + 1}
                    </span>
                    <CardTitle className="text-white text-lg">{scene.title}</CardTitle>
                  </div>
                  <CardDescription className="text-slate-400 line-clamp-2">
                    {scene.prompt}
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-slate-400 bg-slate-700/50 px-3 py-1 rounded">
                    {scene.duration}s
                  </span>
                  {expandedScene === scene.id ? (
                    <ChevronUp className="w-5 h-5 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-slate-400" />
                  )}
                </div>
              </div>
            </CardHeader>

            {expandedScene === scene.id && (
              <CardContent className="space-y-6 pt-0">
                {/* Reference Image */}
                <div className="space-y-3">
                  <Label className="text-slate-200 font-semibold">الصورة المرجعية</Label>
                  {scene.referenceImageUrl ? (
                    <div className="space-y-3">
                      <img
                        src={scene.referenceImageUrl}
                        alt={scene.title}
                        className="w-full h-48 object-cover rounded-lg"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full border-slate-600 text-slate-200 hover:bg-slate-700"
                        onClick={() => {
                          generateImageMutation.mutate({
                            sceneId: scene.id,
                            prompt: scene.referenceImagePrompt || scene.prompt,
                          });
                        }}
                        disabled={generateImageMutation.isPending}
                      >
                        {generateImageMutation.isPending ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            جاري التوليد...
                          </>
                        ) : (
                          <>
                            <ImageIcon className="w-4 h-4 mr-2" />
                            إعادة توليد
                          </>
                        )}
                      </Button>
                    </div>
                  ) : (
                    <Button
                      onClick={() => {
                        generateImageMutation.mutate({
                          sceneId: scene.id,
                          prompt: scene.prompt,
                        });
                      }}
                      disabled={generateImageMutation.isPending}
                      className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white gap-2"
                    >
                      {generateImageMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          جاري التوليد...
                        </>
                      ) : (
                        <>
                          <ImageIcon className="w-4 h-4" />
                          توليد صورة مرجعية
                        </>
                      )}
                    </Button>
                  )}
                </div>

                {/* Scene Details Tabs */}
                <Tabs defaultValue="visual" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 bg-slate-700/50">
                    <TabsTrigger value="visual" className="text-slate-300 data-[state=active]:text-white">
                      بصري
                    </TabsTrigger>
                    <TabsTrigger value="audio" className="text-slate-300 data-[state=active]:text-white">
                      صوتي
                    </TabsTrigger>
                    <TabsTrigger value="cta" className="text-slate-300 data-[state=active]:text-white">
                      CTA
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="visual" className="space-y-4 mt-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label className="text-slate-200">زاوية الكاميرا</Label>
                        <Select
                          value={scene.cameraAngle || ""}
                          onValueChange={(value) => {
                            updateSceneMutation.mutate({
                              sceneId: scene.id,
                              cameraAngle: value,
                            });
                          }}
                        >
                          <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                            <SelectValue placeholder="اختر" />
                          </SelectTrigger>
                          <SelectContent className="bg-slate-700 border-slate-600">
                            {CAMERA_ANGLES.map((angle) => (
                              <SelectItem key={angle.value} value={angle.value} className="text-white">
                                {angle.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label className="text-slate-200">الإضاءة</Label>
                        <Select
                          value={scene.lightingStyle || ""}
                          onValueChange={(value) => {
                            updateSceneMutation.mutate({
                              sceneId: scene.id,
                              lightingStyle: value,
                            });
                          }}
                        >
                          <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                            <SelectValue placeholder="اختر" />
                          </SelectTrigger>
                          <SelectContent className="bg-slate-700 border-slate-600">
                            {LIGHTING_STYLES.map((style) => (
                              <SelectItem key={style.value} value={style.value} className="text-white">
                                {style.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-slate-200">نمط الحركة</Label>
                      <Select
                        value={scene.motionStyle || ""}
                        onValueChange={(value) => {
                          updateSceneMutation.mutate({
                            sceneId: scene.id,
                            motionStyle: value,
                          });
                        }}
                      >
                        <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                          <SelectValue placeholder="اختر" />
                        </SelectTrigger>
                        <SelectContent className="bg-slate-700 border-slate-600">
                          {MOTION_STYLES.map((style) => (
                            <SelectItem key={style.value} value={style.value} className="text-white">
                              {style.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </TabsContent>

                  <TabsContent value="audio" className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label className="text-slate-200">النص الصوتي</Label>
                      <Textarea
                        value={scene.voiceLine || ""}
                        onChange={(e) => {
                          updateSceneMutation.mutate({
                            sceneId: scene.id,
                            voiceLine: e.target.value,
                          });
                        }}
                        className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500 resize-none"
                        rows={3}
                        placeholder="أدخل النص الصوتي للمشهد..."
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="cta" className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label className="text-slate-200">الدعوة للعمل (CTA)</Label>
                      <Input
                        value={scene.cta || ""}
                        onChange={(e) => {
                          updateSceneMutation.mutate({
                            sceneId: scene.id,
                            cta: e.target.value,
                          });
                        }}
                        className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500"
                        placeholder="مثال: اتصل بنا الآن"
                      />
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}
