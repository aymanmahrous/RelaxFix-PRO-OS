import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ChevronRight, ChevronLeft, Sparkles, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface CreativeBriefWizardProps {
  projectId: number;
  onSuccess?: (scriptId: number) => void;
}

type Step = 1 | 2 | 3 | 4;

interface BriefData {
  serviceType: string;
  city: string;
  tone: string;
  targetAudience: string;
  dialect: string;
  duration: string;
  outputFormat: string;
  additionalNotes: string;
}

const SERVICE_TYPES = [
  { value: "real_estate", label: "العقارات" },
  { value: "luxury_goods", label: "السلع الفاخرة" },
  { value: "technology", label: "التكنولوجيا" },
  { value: "hospitality", label: "الضيافة والسياحة" },
  { value: "automotive", label: "السيارات" },
  { value: "fashion", label: "الموضة" },
  { value: "food_beverage", label: "الطعام والشراب" },
  { value: "other", label: "أخرى" },
];

const TONES = [
  { value: "premium", label: "فخم وراقي" },
  { value: "urgent", label: "عاجل وسريع" },
  { value: "calm", label: "هادئ وسلمي" },
  { value: "safe", label: "آمن وموثوق" },
  { value: "exciting", label: "مثير وديناميكي" },
  { value: "emotional", label: "عاطفي ومؤثر" },
];

const DIALECTS = [
  { value: "UAE_Arabic", label: "العربية الإماراتية" },
  { value: "Egyptian_Arabic", label: "العربية المصرية" },
  { value: "Saudi_Arabic", label: "العربية السعودية" },
  { value: "Levantine_Arabic", label: "العربية الشامية" },
  { value: "Modern_Standard_Arabic", label: "الفصحى الحديثة" },
];

const OUTPUT_FORMATS = [
  { value: "Reel", label: "Reel (15-30 ثانية)" },
  { value: "Story", label: "Story (5-15 ثانية)" },
  { value: "Cinematic Trailer", label: "Cinematic Trailer (30-60 ثانية)" },
  { value: "Corporate Ad", label: "Corporate Ad (60+ ثانية)" },
];

export default function CreativeBriefWizard({
  projectId,
  onSuccess,
}: CreativeBriefWizardProps) {
  const [step, setStep] = useState<Step>(1);
  const [briefData, setBriefData] = useState<BriefData>({
    serviceType: "",
    city: "",
    tone: "",
    targetAudience: "",
    dialect: "UAE_Arabic",
    duration: "30",
    outputFormat: "Reel",
    additionalNotes: "",
  });

  const createBriefMutation = trpc.creativeBrief.create.useMutation();
  const generateScriptMutation = trpc.cinematicScript.generate.useMutation({
    onSuccess: (data) => {
      toast.success("تم توليد السكريبت بنجاح!");
      onSuccess?.(data.scriptId);
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ أثناء توليد السكريبت");
    },
  });

  const handleInputChange = (field: keyof BriefData, value: string) => {
    setBriefData((prev) => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    if (step < 4) {
      setStep((step + 1) as Step);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep((step - 1) as Step);
    }
  };

  const handleSubmit = async () => {
    if (!briefData.serviceType || !briefData.tone || !briefData.targetAudience) {
      toast.error("الرجاء ملء جميع الحقول المطلوبة");
      return;
    }

    try {
      // Create brief
      const briefResult = await createBriefMutation.mutateAsync({
        projectId,
        serviceType: briefData.serviceType,
        city: briefData.city,
        tone: briefData.tone,
        targetAudience: briefData.targetAudience,
        dialect: briefData.dialect,
        duration: parseInt(briefData.duration),
        outputFormat: briefData.outputFormat,
        additionalNotes: briefData.additionalNotes,
      });

      // Generate script
      await generateScriptMutation.mutateAsync({
        projectId,
        briefId: briefResult.briefId,
        serviceType: briefData.serviceType,
        tone: briefData.tone,
        targetAudience: briefData.targetAudience,
        duration: parseInt(briefData.duration),
        outputFormat: briefData.outputFormat,
      });
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const isLoading = createBriefMutation.isPending || generateScriptMutation.isPending;

  return (
    <div className="w-full max-w-2xl mx-auto">
      {/* Progress Indicator */}
      <div className="mb-8">
        <div className="flex justify-between mb-4">
          {[1, 2, 3, 4].map((s) => (
            <div
              key={s}
              className={`flex-1 h-2 mx-1 rounded-full transition-colors ${
                s <= step ? "bg-amber-500" : "bg-slate-700"
              }`}
            />
          ))}
        </div>
        <p className="text-sm text-slate-400 text-center">
          الخطوة {step} من 4
        </p>
      </div>

      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            {step === 1 && "نوع الخدمة والموقع"}
            {step === 2 && "النبرة والجمهور المستهدف"}
            {step === 3 && "المدة الزمنية وصيغة الإخراج"}
            {step === 4 && "مراجعة وتأكيد"}
          </CardTitle>
          <CardDescription className="text-slate-400">
            {step === 1 && "اختر نوع الخدمة والمدينة"}
            {step === 2 && "حدد النبرة والجمهور المستهدف"}
            {step === 3 && "اختر المدة الزمنية وصيغة الإخراج"}
            {step === 4 && "تحقق من المعلومات وابدأ التوليد"}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Step 1 */}
          {step === 1 && (
            <>
              <div className="space-y-2">
                <Label htmlFor="serviceType" className="text-slate-200">
                  نوع الخدمة
                </Label>
                <Select value={briefData.serviceType} onValueChange={(value) => handleInputChange("serviceType", value)}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="اختر نوع الخدمة" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    {SERVICE_TYPES.map((type) => (
                      <SelectItem key={type.value} value={type.value} className="text-white">
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="city" className="text-slate-200">
                  المدينة (اختياري)
                </Label>
                <Input
                  id="city"
                  placeholder="مثال: دبي"
                  value={briefData.city}
                  onChange={(e) => handleInputChange("city", e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500"
                />
              </div>
            </>
          )}

          {/* Step 2 */}
          {step === 2 && (
            <>
              <div className="space-y-2">
                <Label htmlFor="tone" className="text-slate-200">
                  نبرة الإعلان
                </Label>
                <Select value={briefData.tone} onValueChange={(value) => handleInputChange("tone", value)}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="اختر النبرة" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    {TONES.map((tone) => (
                      <SelectItem key={tone.value} value={tone.value} className="text-white">
                        {tone.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="targetAudience" className="text-slate-200">
                  الفئة المستهدفة
                </Label>
                <Input
                  id="targetAudience"
                  placeholder="مثال: رجال الأعمال 25-45 سنة"
                  value={briefData.targetAudience}
                  onChange={(e) => handleInputChange("targetAudience", e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="dialect" className="text-slate-200">
                  اللهجة
                </Label>
                <Select value={briefData.dialect} onValueChange={(value) => handleInputChange("dialect", value)}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="اختر اللهجة" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    {DIALECTS.map((dialect) => (
                      <SelectItem key={dialect.value} value={dialect.value} className="text-white">
                        {dialect.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </>
          )}

          {/* Step 3 */}
          {step === 3 && (
            <>
              <div className="space-y-2">
                <Label htmlFor="duration" className="text-slate-200">
                  المدة الزمنية (بالثواني)
                </Label>
                <Input
                  id="duration"
                  type="number"
                  min="5"
                  max="300"
                  value={briefData.duration}
                  onChange={(e) => handleInputChange("duration", e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="outputFormat" className="text-slate-200">
                  صيغة الإخراج
                </Label>
                <Select value={briefData.outputFormat} onValueChange={(value) => handleInputChange("outputFormat", value)}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="اختر صيغة الإخراج" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    {OUTPUT_FORMATS.map((format) => (
                      <SelectItem key={format.value} value={format.value} className="text-white">
                        {format.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </>
          )}

          {/* Step 4 */}
          {step === 4 && (
            <>
              <div className="space-y-2">
                <Label htmlFor="additionalNotes" className="text-slate-200">
                  ملاحظات إضافية (اختياري)
                </Label>
                <Textarea
                  id="additionalNotes"
                  placeholder="أضف أي ملاحظات أو متطلبات إضافية..."
                  value={briefData.additionalNotes}
                  onChange={(e) => handleInputChange("additionalNotes", e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500 resize-none"
                  rows={4}
                />
              </div>

              <div className="bg-slate-700/50 rounded-lg p-4 space-y-2 text-sm">
                <p className="text-slate-200"><strong>نوع الخدمة:</strong> {SERVICE_TYPES.find(t => t.value === briefData.serviceType)?.label}</p>
                <p className="text-slate-200"><strong>النبرة:</strong> {TONES.find(t => t.value === briefData.tone)?.label}</p>
                <p className="text-slate-200"><strong>الجمهور:</strong> {briefData.targetAudience}</p>
                <p className="text-slate-200"><strong>المدة:</strong> {briefData.duration} ثانية</p>
                <p className="text-slate-200"><strong>الصيغة:</strong> {OUTPUT_FORMATS.find(f => f.value === briefData.outputFormat)?.label}</p>
              </div>
            </>
          )}

          {/* Navigation Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              onClick={handleBack}
              variant="outline"
              className="flex-1 border-slate-600 text-slate-200 hover:bg-slate-700 gap-2"
              disabled={step === 1 || isLoading}
            >
              <ChevronLeft className="w-4 h-4" />
              السابق
            </Button>

            {step < 4 ? (
              <Button
                onClick={handleNext}
                className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-semibold gap-2"
                disabled={isLoading}
              >
                التالي
                <ChevronRight className="w-4 h-4" />
              </Button>
            ) : (
              <Button
                onClick={handleSubmit}
                className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white font-semibold gap-2"
                disabled={isLoading}
              >
                {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
                {isLoading ? "جاري التوليد..." : "توليد السكريبت"}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
