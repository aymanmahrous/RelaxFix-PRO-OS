import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Loader2 } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

interface ProjectCreationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export default function ProjectCreationDialog({
  open,
  onOpenChange,
  onSuccess,
}: ProjectCreationDialogProps) {
  const [, setLocation] = useLocation();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  
  const createProjectMutation = trpc.projects.create.useMutation({
    onSuccess: (data) => {
      toast.success("تم إنشاء المشروع بنجاح!");
      onOpenChange(false);
      setTitle("");
      setDescription("");
      onSuccess?.();
      // Navigate to project
      setLocation(`/project/${data.projectId}`);
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ أثناء إنشاء المشروع");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      toast.error("الرجاء إدخال عنوان المشروع");
      return;
    }
    createProjectMutation.mutate({
      title: title.trim(),
      description: description.trim() || undefined,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white">مشروع جديد</DialogTitle>
          <DialogDescription className="text-slate-400">
            أنشئ مشروعاً جديداً لبدء إنشاء السكريبت السينمائي
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-slate-200">
              عنوان المشروع
            </Label>
            <Input
              id="title"
              placeholder="مثال: إعلان منتج جديد"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500"
              disabled={createProjectMutation.isPending}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-slate-200">
              الوصف (اختياري)
            </Label>
            <Textarea
              id="description"
              placeholder="أضف وصفاً للمشروع..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500 resize-none"
              rows={3}
              disabled={createProjectMutation.isPending}
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1 border-slate-600 text-slate-200 hover:bg-slate-700"
              disabled={createProjectMutation.isPending}
            >
              إلغاء
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-semibold gap-2"
              disabled={createProjectMutation.isPending}
            >
              {createProjectMutation.isPending && (
                <Loader2 className="w-4 h-4 animate-spin" />
              )}
              إنشاء المشروع
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
