import { Card } from "@/components/ui/card";

interface LoadingSkeletonProps {
  count?: number;
  type?: "card" | "text" | "image";
}

export function CardSkeleton() {
  return (
    <Card className="bg-slate-800 border-slate-700 overflow-hidden">
      <div className="p-6 space-y-4">
        <div className="skeleton h-6 w-2/3 rounded" />
        <div className="skeleton h-4 w-full rounded" />
        <div className="skeleton h-4 w-5/6 rounded" />
      </div>
    </Card>
  );
}

export function TextSkeleton() {
  return (
    <div className="space-y-3">
      <div className="skeleton h-4 w-full rounded" />
      <div className="skeleton h-4 w-5/6 rounded" />
      <div className="skeleton h-4 w-4/6 rounded" />
    </div>
  );
}

export function ImageSkeleton() {
  return <div className="skeleton w-full h-48 rounded-lg" />;
}

export function ProjectCardSkeleton() {
  return (
    <Card className="bg-slate-800 border-slate-700">
      <div className="p-6 space-y-4">
        <div className="flex items-start justify-between">
          <div className="flex-1 space-y-2">
            <div className="skeleton h-6 w-2/3 rounded" />
            <div className="skeleton h-4 w-full rounded" />
          </div>
          <div className="skeleton h-6 w-16 rounded" />
        </div>
        <div className="skeleton h-4 w-1/3 rounded" />
      </div>
    </Card>
  );
}

export default function LoadingSkeleton({
  count = 3,
  type = "card",
}: LoadingSkeletonProps) {
  const items = Array.from({ length: count });

  return (
    <div className="space-y-4">
      {items.map((_, i) => (
        <div key={i}>
          {type === "card" && <CardSkeleton />}
          {type === "text" && <TextSkeleton />}
          {type === "image" && <ImageSkeleton />}
        </div>
      ))}
    </div>
  );
}
