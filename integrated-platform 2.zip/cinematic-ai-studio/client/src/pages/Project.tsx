import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Film, ArrowLeft, Sparkles, Zap } from "lucide-react";
import CreativeBriefWizard from "@/components/CreativeBriefWizard";
import SceneEditor from "@/components/SceneEditor";

export default function Project() {
  const [, setLocation] = useLocation();
  const [projectId, setProjectId] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState("brief");

  // Extract projectId from URL
  useEffect(() => {
    const match = window.location.pathname.match(/\/project\/(\d+)/);
    if (match) {
      setProjectId(parseInt(match[1]));
    }
  }, []);

  const projectQuery = trpc.projects.get.useQuery(
    { projectId: projectId! },
    { enabled: projectId !== null }
  );

  const scriptQuery = trpc.cinematicScript.getByProject.useQuery(
    { projectId: projectId! },
    { enabled: projectId !== null }
  );

  if (!projectId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <p className="text-white text-lg">جاري تحميل المشروع...</p>
        </div>
      </div>
    );
  }

  if (projectQuery.isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-amber-400"></div>
          <p className="mt-4 text-white">جاري تحميل المشروع...</p>
        </div>
      </div>
    );
  }

  const project = projectQuery.data;
  const script = scriptQuery.data;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700/50 bg-slate-900/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/")}
              className="text-slate-400 hover:text-white"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl font-bold text-white">{project?.title}</h1>
              <p className="text-sm text-slate-400">{project?.description}</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {!script ? (
          // Creative Brief Step
          <div className="space-y-8">
            <div className="text-center mb-12">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/30 mb-4">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span className="text-sm text-amber-300">الخطوة 1: إنشاء Brief</span>
              </div>
              <h2 className="text-4xl font-bold text-white mb-4">
                دعنا نبدأ بإنشاء سكريبتك السينمائي
              </h2>
              <p className="text-slate-300 max-w-2xl mx-auto">
                أخبرنا عن مشروعك وسيقوم الذكاء الاصطناعي بتوليد سكريبت احترافي يناسب احتياجاتك
              </p>
            </div>

            <CreativeBriefWizard
              projectId={projectId}
              onSuccess={(scriptId) => {
                scriptQuery.refetch();
                setActiveTab("scenes");
              }}
            />
          </div>
        ) : (
          // Script Editor Step
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-slate-800 border-slate-700">
              <TabsTrigger value="brief" className="text-slate-300 data-[state=active]:text-white">
                <Sparkles className="w-4 h-4 mr-2" />
                Brief
              </TabsTrigger>
              <TabsTrigger value="scenes" className="text-slate-300 data-[state=active]:text-white">
                <Film className="w-4 h-4 mr-2" />
                المشاهد
              </TabsTrigger>
              <TabsTrigger value="export" className="text-slate-300 data-[state=active]:text-white">
                <Zap className="w-4 h-4 mr-2" />
                التصدير
              </TabsTrigger>
            </TabsList>

            <TabsContent value="brief" className="space-y-6 mt-6">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">ملخص المشروع</CardTitle>
                  <CardDescription className="text-slate-400">
                    {script.title}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-300">{script.synopsis}</p>
                  <div className="mt-4 text-sm text-slate-400">
                    <p>المدة الإجمالية: {script.totalDuration} ثانية</p>
                    <p>عدد المشاهد: {script.totalDuration ? "3-5" : "0"}</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="scenes" className="space-y-6 mt-6">
              <SceneEditor scriptId={script.id} />
            </TabsContent>

            <TabsContent value="export" className="space-y-6 mt-6">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">مركز التصدير</CardTitle>
                  <CardDescription className="text-slate-400">
                    صدّر السكريبت بصيغ مختلفة
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Button className="bg-slate-700 hover:bg-slate-600 text-white gap-2">
                      <Film className="w-4 h-4" />
                      تصدير PDF
                    </Button>
                    <Button className="bg-slate-700 hover:bg-slate-600 text-white gap-2">
                      <Zap className="w-4 h-4" />
                      تصدير JSON
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </main>
    </div>
  );
}
