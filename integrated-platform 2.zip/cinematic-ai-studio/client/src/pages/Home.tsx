import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Film, Sparkles, Zap, Palette, Download, Clock, Settings } from "lucide-react";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { useLocation } from "wouter";
import ProjectCreationDialog from "@/components/ProjectCreationDialog";
import { ProjectCardSkeleton } from "@/components/LoadingSkeleton";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [showCreateProject, setShowCreateProject] = useState(false);
  
  const projectsQuery = trpc.projects.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
          <p className="mt-4 text-white">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        {/* Navigation */}
        <nav className="border-b border-slate-700/50 bg-slate-900/50 backdrop-blur-xl sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Film className="w-8 h-8 text-amber-400" />
              <span className="text-xl font-bold text-white">Cinematic AI Studio</span>
            </div>
            <Button onClick={() => window.location.href = getLoginUrl()} className="bg-amber-500 hover:bg-amber-600 text-black font-semibold">
              دخول / تسجيل
            </Button>
          </div>
        </nav>

        {/* Hero Section */}
        <section className="relative overflow-hidden pt-20 pb-32">
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl"></div>
          </div>

          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/30 mb-6">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="text-sm text-amber-300">مدعوم بالذكاء الاصطناعي</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              إنشاء السكريبتات السينمائية
              <span className="bg-gradient-to-r from-amber-400 to-orange-400 bg-clip-text text-transparent"> بلحظات</span>
            </h1>

            <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
              منصة احترافية لتحويل أفكارك إلى سكريبتات سينمائية مذهلة. استخدم الذكاء الاصطناعي لتوليد المحتوى البصري والصوتي بسهولة.
            </p>

            <Button 
              onClick={() => window.location.href = getLoginUrl()}
              className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold py-6 px-8 text-lg rounded-lg"
            >
              ابدأ الآن مجاناً
            </Button>
          </div>
        </section>

        {/* Features Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <h2 className="text-4xl font-bold text-white text-center mb-16">الميزات الرئيسية</h2>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Sparkles,
                title: "توليد ذكي للسكريبتات",
                description: "استخدم الذكاء الاصطناعي لتوليد سكريبتات احترافية من وصف بسيط",
              },
              {
                icon: Film,
                title: "محرر مشاهد بصري",
                description: "عدّل كل مشهد بسهولة مع معاينة فورية والتحكم الكامل في التفاصيل",
              },
              {
                icon: Palette,
                title: "Brand Kit متكامل",
                description: "احفظ هويتك البصرية وطبقها تلقائياً على جميع المشاريع",
              },
              {
                icon: Zap,
                title: "توليد الصور المرجعية",
                description: "أنشئ صوراً مرجعية احترافية لكل مشهد بنقرة واحدة",
              },
              {
                icon: Clock,
                title: "Timeline تفاعلي",
                description: "رتب وعدّل المشاهد بسهولة مع عرض مرئي شامل",
              },
              {
                icon: Download,
                title: "تصدير احترافي",
                description: "صدّر السكريبت بصيغ متعددة جاهزة للإنتاج",
              },
            ].map((feature, i) => (
              <Card key={i} className="bg-slate-800/50 border-slate-700/50 hover:border-amber-500/50 transition-colors">
                <CardHeader>
                  <feature.icon className="w-8 h-8 text-amber-400 mb-2" />
                  <CardTitle className="text-white">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-300">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">جاهز لبدء رحلتك الإبداعية؟</h2>
          <Button 
            onClick={() => window.location.href = getLoginUrl()}
            className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold py-6 px-8 text-lg rounded-lg"
          >
            ابدأ الآن مجاناً
          </Button>
        </section>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700/50 bg-slate-900/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Film className="w-8 h-8 text-amber-400" />
            <span className="text-xl font-bold text-white">Cinematic AI Studio</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-slate-300">مرحباً، {user?.name}</span>
            <Button variant="outline" size="sm" onClick={() => window.location.href = getLoginUrl()}>
              تسجيل الخروج
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Welcome Section */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-white mb-2">مشاريعك</h1>
          <p className="text-slate-300">إدارة وإنشاء السكريبتات السينمائية الخاصة بك</p>
        </div>

        {/* Create Project Button */}
        <div className="mb-8">
          <Button 
            onClick={() => setShowCreateProject(true)}
            className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold gap-2"
          >
            <Plus className="w-4 h-4" />
            مشروع جديد
          </Button>
        </div>

        {/* Projects Grid */}
        {projectsQuery.isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <ProjectCardSkeleton key={i} />
            ))}
          </div>
        ) : projectsQuery.data && projectsQuery.data.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fadeInUp">
            {projectsQuery.data.map((project, index) => (
              <div key={project.id} style={{ animationDelay: `${index * 50}ms` }} className="animate-fadeInUp">
                <Card 
                  className="bg-slate-800/50 border-slate-700/50 hover:border-amber-500/50 transition-all cursor-pointer hover:shadow-lg hover:shadow-amber-500/10"
                  onClick={() => setLocation(`/project/${project.id}`)}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-white">{project.title}</CardTitle>
                        <CardDescription className="text-slate-400">
                          {project.description || "بدون وصف"}
                        </CardDescription>
                      </div>
                      <span className={`px-2 py-1 rounded text-xs font-semibold ${
                        project.status === 'draft' ? 'bg-slate-700 text-slate-200' :
                        project.status === 'in_progress' ? 'bg-blue-900/50 text-blue-200' :
                        project.status === 'completed' ? 'bg-green-900/50 text-green-200' :
                        'bg-gray-900/50 text-gray-200'
                      }`}>
                        {project.status === 'draft' ? 'مسودة' :
                         project.status === 'in_progress' ? 'قيد الإنجاز' :
                         project.status === 'completed' ? 'مكتمل' :
                         'مؤرشف'}
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm text-slate-400">
                      <span>{new Date(project.createdAt).toLocaleDateString('ar-SA')}</span>
                      <Film className="w-4 h-4" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <Film className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">لا توجد مشاريع بعد</h3>
            <p className="text-slate-400 mb-6">ابدأ بإنشاء مشروع جديد لبدء رحلتك الإبداعية</p>
            <Button 
              onClick={() => setShowCreateProject(true)}
              className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold gap-2"
            >
              <Plus className="w-4 h-4" />
              مشروع جديد
            </Button>
          </div>
        )}
      </main>

      {/* Create Project Dialog */}
      <ProjectCreationDialog 
        open={showCreateProject} 
        onOpenChange={setShowCreateProject}
        onSuccess={() => {
          setShowCreateProject(false);
          projectsQuery.refetch();
        }}
      />
    </div>
  );
}
