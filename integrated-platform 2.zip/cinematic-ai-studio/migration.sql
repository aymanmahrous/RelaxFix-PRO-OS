CREATE TABLE `brandKits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`logoUrl` varchar(500),
	`primaryColor` varchar(7),
	`secondaryColor` varchar(7),
	`accentColor` varchar(7),
	`fontFamily` varchar(100),
	`phoneNumber` varchar(20),
	`ctaText` varchar(100),
	`ctaAnimationStyle` varchar(100),
	`watermarkUrl` varchar(500),
	`footerLockup` text,
	`isDefault` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `brandKits_id` PRIMARY KEY(`id`)
);
;
CREATE TABLE `cinematicScripts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`briefId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`synopsis` text,
	`totalDuration` int NOT NULL,
	`generatedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cinematicScripts_id` PRIMARY KEY(`id`)
);
;
CREATE TABLE `creativeBriefs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`serviceType` varchar(100) NOT NULL,
	`city` varchar(100),
	`tone` varchar(100) NOT NULL,
	`targetAudience` varchar(255) NOT NULL,
	`dialect` varchar(50) NOT NULL,
	`duration` int NOT NULL,
	`outputFormat` varchar(50) NOT NULL,
	`additionalNotes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `creativeBriefs_id` PRIMARY KEY(`id`)
);
;
CREATE TABLE `exports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`scriptId` int NOT NULL,
	`format` varchar(50) NOT NULL,
	`fileUrl` varchar(500) NOT NULL,
	`fileSize` int,
	`exportedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `exports_id` PRIMARY KEY(`id`)
);
;
CREATE TABLE `projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`status` enum('draft','in_progress','completed','archived') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `projects_id` PRIMARY KEY(`id`)
);
;
CREATE TABLE `scenes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`scriptId` int NOT NULL,
	`sceneNumber` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`prompt` text NOT NULL,
	`cameraAngle` varchar(100),
	`lensStyle` varchar(100),
	`lightingStyle` varchar(100),
	`motionStyle` varchar(100),
	`voiceLine` text,
	`cta` varchar(255),
	`productTags` varchar(255),
	`duration` int NOT NULL,
	`referenceImageUrl` varchar(500),
	`referenceImagePrompt` text,
	`sequenceOrder` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `scenes_id` PRIMARY KEY(`id`)
);
;
CREATE TABLE `scriptTemplates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`category` varchar(100) NOT NULL,
	`templateData` text,
	`previewImageUrl` varchar(500),
	`isActive` int DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `scriptTemplates_id` PRIMARY KEY(`id`)
);
;
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
;
ALTER TABLE `brandKits` ADD CONSTRAINT `brandKits_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;;
ALTER TABLE `cinematicScripts` ADD CONSTRAINT `cinematicScripts_projectId_projects_id_fk` FOREIGN KEY (`projectId`) REFERENCES `projects`(`id`) ON DELETE cascade ON UPDATE no action;;
ALTER TABLE `cinematicScripts` ADD CONSTRAINT `cinematicScripts_briefId_creativeBriefs_id_fk` FOREIGN KEY (`briefId`) REFERENCES `creativeBriefs`(`id`) ON DELETE cascade ON UPDATE no action;;
ALTER TABLE `creativeBriefs` ADD CONSTRAINT `creativeBriefs_projectId_projects_id_fk` FOREIGN KEY (`projectId`) REFERENCES `projects`(`id`) ON DELETE cascade ON UPDATE no action;;
ALTER TABLE `exports` ADD CONSTRAINT `exports_scriptId_cinematicScripts_id_fk` FOREIGN KEY (`scriptId`) REFERENCES `cinematicScripts`(`id`) ON DELETE cascade ON UPDATE no action;;
ALTER TABLE `projects` ADD CONSTRAINT `projects_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;;
ALTER TABLE `scenes` ADD CONSTRAINT `scenes_scriptId_cinematicScripts_id_fk` FOREIGN KEY (`scriptId`) REFERENCES `cinematicScripts`(`id`) ON DELETE cascade ON UPDATE no action;