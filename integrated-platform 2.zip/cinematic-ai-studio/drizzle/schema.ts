import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Projects table: stores cinematic script projects
 */
export const projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["draft", "in_progress", "completed", "archived"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;

/**
 * Creative Briefs: stores the initial brief information for each project
 */
export const creativeBriefs = mysqlTable("creativeBriefs", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull().references(() => projects.id, { onDelete: "cascade" }),
  serviceType: varchar("serviceType", { length: 100 }).notNull(), // e.g., "real_estate", "luxury_goods", "tech"
  city: varchar("city", { length: 100 }),
  tone: varchar("tone", { length: 100 }).notNull(), // e.g., "premium", "urgent", "calm", "safe"
  targetAudience: varchar("targetAudience", { length: 255 }).notNull(),
  dialect: varchar("dialect", { length: 50 }).notNull(), // e.g., "UAE_Arabic", "Egyptian_Arabic"
  duration: int("duration").notNull(), // in seconds
  outputFormat: varchar("outputFormat", { length: 50 }).notNull(), // "Reel", "Story", "Cinematic Trailer", "Corporate Ad"
  additionalNotes: text("additionalNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CreativeBrief = typeof creativeBriefs.$inferSelect;
export type InsertCreativeBrief = typeof creativeBriefs.$inferInsert;

/**
 * Cinematic Scripts: stores the generated script with all scenes
 */
export const cinematicScripts = mysqlTable("cinematicScripts", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull().references(() => projects.id, { onDelete: "cascade" }),
  briefId: int("briefId").notNull().references(() => creativeBriefs.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  synopsis: text("synopsis"),
  totalDuration: int("totalDuration").notNull(), // in seconds
  generatedAt: timestamp("generatedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CinematicScript = typeof cinematicScripts.$inferSelect;
export type InsertCinematicScript = typeof cinematicScripts.$inferInsert;

/**
 * Scenes: individual scenes within a cinematic script
 */
export const scenes = mysqlTable("scenes", {
  id: int("id").autoincrement().primaryKey(),
  scriptId: int("scriptId").notNull().references(() => cinematicScripts.id, { onDelete: "cascade" }),
  sceneNumber: int("sceneNumber").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  prompt: text("prompt").notNull(), // Main AI prompt for scene
  cameraAngle: varchar("cameraAngle", { length: 100 }), // drone, macro, gimbal, close-up
  lensStyle: varchar("lensStyle", { length: 100 }), // e.g., "35mm", "50mm", "85mm"
  lightingStyle: varchar("lightingStyle", { length: 100 }), // golden hour, cool blue, luxury indoor
  motionStyle: varchar("motionStyle", { length: 100 }), // e.g., "smooth pan", "dynamic cut"
  voiceLine: text("voiceLine"),
  cta: varchar("cta", { length: 255 }), // Call to action
  productTags: varchar("productTags", { length: 255 }), // comma-separated
  duration: int("duration").notNull(), // in seconds
  referenceImageUrl: varchar("referenceImageUrl", { length: 500 }), // URL to generated reference image
  referenceImagePrompt: text("referenceImagePrompt"), // Prompt used to generate image
  sequenceOrder: int("sequenceOrder").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Scene = typeof scenes.$inferSelect;
export type InsertScene = typeof scenes.$inferInsert;

/**
 * Brand Kits: stores brand identity for reuse across projects
 */
export const brandKits = mysqlTable("brandKits", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  logoUrl: varchar("logoUrl", { length: 500 }),
  primaryColor: varchar("primaryColor", { length: 7 }), // hex color
  secondaryColor: varchar("secondaryColor", { length: 7 }),
  accentColor: varchar("accentColor", { length: 7 }),
  fontFamily: varchar("fontFamily", { length: 100 }), // e.g., "Inter", "Playfair Display"
  phoneNumber: varchar("phoneNumber", { length: 20 }),
  ctaText: varchar("ctaText", { length: 100 }),
  ctaAnimationStyle: varchar("ctaAnimationStyle", { length: 100 }), // e.g., "pulse", "bounce", "fade"
  watermarkUrl: varchar("watermarkUrl", { length: 500 }),
  footerLockup: text("footerLockup"), // JSON with footer elements
  isDefault: int("isDefault").default(0), // 0 or 1 for boolean
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BrandKit = typeof brandKits.$inferSelect;
export type InsertBrandKit = typeof brandKits.$inferInsert;

/**
 * Script Templates: preset patterns for quick start
 */
export const scriptTemplates = mysqlTable("scriptTemplates", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 100 }).notNull(), // "luxury_gulf", "social_reel", "corporate_film"
  templateData: text("templateData"), // JSON with template structure
  previewImageUrl: varchar("previewImageUrl", { length: 500 }),
  isActive: int("isActive").default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ScriptTemplate = typeof scriptTemplates.$inferSelect;
export type InsertScriptTemplate = typeof scriptTemplates.$inferInsert;

/**
 * Exports: tracks generated exports for projects
 */
export const exports = mysqlTable("exports", {
  id: int("id").autoincrement().primaryKey(),
  scriptId: int("scriptId").notNull().references(() => cinematicScripts.id, { onDelete: "cascade" }),
  format: varchar("format", { length: 50 }).notNull(), // "pdf", "json", "9:16", "16:9", "1:1"
  fileUrl: varchar("fileUrl", { length: 500 }).notNull(),
  fileSize: int("fileSize"), // in bytes
  exportedAt: timestamp("exportedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Export = typeof exports.$inferSelect;
export type InsertExport = typeof exports.$inferInsert;