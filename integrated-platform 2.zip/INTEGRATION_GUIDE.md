# 🔗 دليل دمج المنصات

## ماشاء الله - ولا حول ولا قوة الا بالله

---

## 📦 خطوات الدمج

### 1️⃣ **الخطوة الأولى: نقل ملفات Cinematic AI**

```bash
# انسخ جميع ملفات Cinematic AI إلى المشروع الرئيسي
cp -r cinematic-ai-studio/client ./
cp -r cinematic-ai-studio/server ./
cp -r cinematic-ai-studio/drizzle ./
cp cinematic-ai-studio/package.json ./package-cinematic.json
```

### 2️⃣ **الخطوة الثانية: دمج المكتبات**

```bash
# استخدم package-integrated.json
cp package-integrated.json package.json

# ثبت المكتبات
pnpm install
```

### 3️⃣ **الخطوة الثالثة: دمج قواعد البيانات**

**إضافة جداول RelaxFix إلى Drizzle schema:**

```typescript
// drizzle/schema.ts - أضف الجداول التالية:

// جدول الطلبات
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  projectId: int("projectId"),
  status: varchar("status", { length: 50 }).default("pending"),
  amount: decimal("amount", { precision: 10, scale: 2 }),
  createdAt: timestamp("createdAt").defaultNow(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow(),
});

// جدول المستخدمين المتقدمة
export const userProfiles = mysqlTable("userProfiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  phone: varchar("phone", { length: 20 }),
  address: text("address"),
  preferences: json("preferences"),
  createdAt: timestamp("createdAt").defaultNow(),
});

// جدول الإشعارات
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: varchar("type", { length: 50 }),
  message: text("message"),
  read: boolean("read").default(false),
  createdAt: timestamp("createdAt").defaultNow(),
});
```

### 4️⃣ **الخطوة الرابعة: دمج الـ APIs**

**إنشاء ملف تكامل جديد:**

```typescript
// server/routers/integration.ts

import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { z } from "zod";

export const integrationRouter = router({
  // ربط السكريبت بالطلب
  linkScriptToOrder: protectedProcedure
    .input(z.object({
      scriptId: z.number(),
      orderId: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      // تنفيذ الربط
      return { success: true };
    }),

  // الحصول على الطلبات مع السكريبتات
  getOrdersWithScripts: protectedProcedure
    .query(async ({ ctx }) => {
      // جلب الطلبات مع السكريبتات المرتبطة
      return [];
    }),

  // إنشاء طلب من سكريبت
  createOrderFromScript: protectedProcedure
    .input(z.object({
      scriptId: z.number(),
      quantity: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      // إنشاء طلب جديد
      return { orderId: 1 };
    }),
});
```

### 5️⃣ **الخطوة الخامسة: دمج الواجهات**

**إضافة صفحات جديدة:**

```typescript
// client/src/pages/Orders.tsx
// client/src/pages/Integration.tsx
// client/src/pages/Dashboard.tsx
```

### 6️⃣ **الخطوة السادسة: تحديث الـ Router الرئيسي**

```typescript
// server/routers.ts

import { integrationRouter } from "./routers/integration";

export const appRouter = router({
  cinematic: cinematicRouter,
  relaxfix: relaxfixRouter,
  integration: integrationRouter,
  // ...
});
```

---

## 🔄 نقاط التكامل الرئيسية

### 1. **نظام الطلبات المتقدم**

```
السكريبت السينمائي
    ↓
إنشاء طلب إنتاج
    ↓
تتبع الحالة
    ↓
الدفع والإشعارات
    ↓
تسليم النتيجة النهائية
```

### 2. **نظام الدفع المتكامل**

- ربط Stripe مع الطلبات
- إدارة الفواتير
- تقارير المبيعات

### 3. **نظام التنبيهات**

- إشعارات Telegram
- إشعارات WhatsApp
- إشعارات البريد الإلكتروني

### 4. **لوحة التحكم الموحدة**

- إحصائيات مدمجة
- إدارة المستخدمين
- تقارير شاملة

---

## 📊 البنية النهائية

```
integrated-platform/
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.tsx              # الصفحة الرئيسية
│   │   │   ├── Project.tsx           # مشروع السكريبت
│   │   │   ├── Orders.tsx            # إدارة الطلبات
│   │   │   ├── Dashboard.tsx         # لوحة التحكم
│   │   │   └── Integration.tsx       # نقاط التكامل
│   │   └── components/
│   └── ...
├── server/
│   ├── routers/
│   │   ├── cinematic.ts              # روتات Cinematic
│   │   ├── relaxfix.ts               # روتات RelaxFix
│   │   └── integration.ts            # روتات التكامل
│   ├── db.ts
│   └── ...
├── drizzle/
│   └── schema.ts                     # جميع الجداول
├── relaxfix-app/                     # التطبيق الأصلي
├── cinematic-ai-studio/              # المشروع الأصلي
└── package.json
```

---

## 🚀 التشغيل

```bash
# 1. تثبيت المكتبات
pnpm install

# 2. تشغيل الخادم
pnpm dev

# 3. فتح المتصفح
# http://localhost:3000
```

---

## ✅ قائمة التحقق

- [ ] نسخ ملفات Cinematic AI
- [ ] دمج المكتبات
- [ ] إضافة جداول RelaxFix
- [ ] دمج الـ APIs
- [ ] دمج الواجهات
- [ ] اختبار التكامل
- [ ] النشر

---

## 📞 الدعم

للمزيد من المعلومات، راجع:
- `INTEGRATION_PLAN.md` - خطة الدمج الشاملة
- `cinematic-ai-studio/README.md` - توثيق Cinematic AI
- `relaxfix-app/README.md` - توثيق RelaxFix
