CREATE TABLE `backupHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`backupType` enum('automatic','manual') DEFAULT 'automatic',
	`backupUrl` varchar(500) NOT NULL,
	`backupSize` int,
	`status` enum('completed','failed') DEFAULT 'completed',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `backupHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `designTemplates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`category` varchar(100) NOT NULL,
	`thumbnail` varchar(500),
	`templateData` json,
	`isActive` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `designTemplates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `subscriptionHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`planId` int NOT NULL,
	`startDate` timestamp NOT NULL,
	`endDate` timestamp,
	`amount` decimal(10,2) NOT NULL,
	`status` enum('active','cancelled','expired') DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `subscriptionHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `twoFactorAuth` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`secret` varchar(255) NOT NULL,
	`isEnabled` boolean DEFAULT false,
	`backupCodes` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `twoFactorAuth_id` PRIMARY KEY(`id`),
	CONSTRAINT `twoFactorAuth_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `userDesigns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`designData` json,
	`thumbnail` varchar(500),
	`exportedUrl` varchar(500),
	`status` enum('draft','published','archived') DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userDesigns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `videoJobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`script` text,
	`status` enum('pending','processing','completed','failed') DEFAULT 'pending',
	`videoUrl` varchar(500),
	`thumbnailUrl` varchar(500),
	`duration` int,
	`coinsUsed` decimal(10,2) DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `videoJobs_id` PRIMARY KEY(`id`)
);
