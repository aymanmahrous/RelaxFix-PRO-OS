CREATE TABLE `adminSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`adminPassword` varchar(255) NOT NULL,
	`defaultPoemId` int,
	`defaultMusicId` int,
	`defaultQuranId` int,
	`autoPlayEnabled` boolean DEFAULT true,
	`autoPlayVolume` decimal(3,2) DEFAULT '0.3',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `adminSettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `adminSettings_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `audioContent` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`type` enum('poem','music','quran','other') NOT NULL,
	`audioUrl` varchar(500) NOT NULL,
	`fileKey` varchar(255) NOT NULL,
	`duration` int,
	`isActive` boolean DEFAULT false,
	`isDefault` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `audioContent_id` PRIMARY KEY(`id`)
);
