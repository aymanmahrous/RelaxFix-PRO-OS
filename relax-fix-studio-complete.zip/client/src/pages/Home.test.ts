import { describe, it, expect, beforeEach, vi } from 'vitest';

describe('Home Page - Language Support', () => {
  beforeEach(() => {
    // Clear localStorage before each test
    localStorage.clear();
  });

  it('should render with Arabic as default language', () => {
    const stored = localStorage.getItem('language');
    expect(stored).toBeNull(); // Initially empty
  });

  it('should persist language preference to localStorage', () => {
    localStorage.setItem('language', 'ar');
    const stored = localStorage.getItem('language');
    expect(stored).toBe('ar');
  });

  it('should support English language', () => {
    localStorage.setItem('language', 'en');
    const stored = localStorage.getItem('language');
    expect(stored).toBe('en');
  });

  it('should have valid language values', () => {
    const validLanguages = ['ar', 'en'];
    const testLang = 'ar';
    expect(validLanguages).toContain(testLang);
  });

  it('should handle language switching', () => {
    localStorage.setItem('language', 'ar');
    expect(localStorage.getItem('language')).toBe('ar');
    
    localStorage.setItem('language', 'en');
    expect(localStorage.getItem('language')).toBe('en');
    
    localStorage.setItem('language', 'ar');
    expect(localStorage.getItem('language')).toBe('ar');
  });

  it('should set RTL direction for Arabic', () => {
    const language = 'ar';
    const dir = language === 'ar' ? 'rtl' : 'ltr';
    expect(dir).toBe('rtl');
  });

  it('should set LTR direction for English', () => {
    const language = 'en';
    const dir = language === 'ar' ? 'rtl' : 'ltr';
    expect(dir).toBe('ltr');
  });

  it('should have navigation links pointing to internal routes', () => {
    const routes = ['/dashboard', '/design-editor', '/video-generator', '/pricing'];
    routes.forEach(route => {
      expect(route).toMatch(/^\//);
    });
  });

  it('should not redirect to Manus OAuth', () => {
    // Verify that getLoginUrl is not being called
    const manusDomain = 'manus.im';
    const internalRoute = '/dashboard';
    expect(internalRoute).not.toContain(manusDomain);
  });

  it('should have all required translation keys', () => {
    const requiredKeys = [
      'nav.login',
      'nav.start',
      'nav.dashboard',
      'home.cta.start',
    ];
    
    requiredKeys.forEach(key => {
      expect(key).toMatch(/^[a-z]+\.[a-z]+$/);
    });
  });

  it('should support poem modal functionality', () => {
    const poemContent = {
      ar: 'نانا يا نانا',
      en: 'Nana, oh Nana'
    };
    
    expect(poemContent.ar).toBeTruthy();
    expect(poemContent.en).toBeTruthy();
  });

  it('should have audio player with play/pause controls', () => {
    const audioStates = ['playing', 'paused'];
    expect(audioStates).toContain('playing');
    expect(audioStates).toContain('paused');
  });

  it('should have contact information', () => {
    const phone = '+971588259848';
    const email = 'info@relaxfix.ae';
    
    expect(phone).toMatch(/^\+\d+/);
    expect(email).toMatch(/@/);
  });

  it('should have Abu Dhabi landmarks section', () => {
    const landmarks = ['Corniche', 'Grand Mosque', 'Burj Khalifa', 'Yas Island', 'Emirates Palace', 'Zoo Park'];
    expect(landmarks.length).toBe(6);
  });

  it('should have pricing plans', () => {
    const plans = ['Starter', 'Pro', 'Enterprise'];
    expect(plans.length).toBe(3);
  });

  it('should have footer with social links', () => {
    const socialLinks = ['telegram', 'whatsapp'];
    expect(socialLinks).toContain('telegram');
    expect(socialLinks).toContain('whatsapp');
  });
});
