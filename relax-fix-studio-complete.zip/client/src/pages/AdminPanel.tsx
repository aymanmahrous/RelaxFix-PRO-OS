import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";

import { Lock, Music, FileAudio, Settings, Upload, Trash2, Star } from 'lucide-react';

/**
 * Admin Control Panel - Manage audio content, poems, music, and Quran
 */
export default function AdminPanel() {
  const { user, isAuthenticated } = useAuth();

  const [isPasswordProtected] = useState(true);
  const [passwordInput, setPasswordInput] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [adminPassword] = useState('admin123');

  useEffect(() => {
    if (!isAuthenticated) {
      window.location.href = '/';
    }
    if (user?.role !== 'admin') {
      window.location.href = '/dashboard';
    }
  }, [isAuthenticated, user]);

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === adminPassword) {
      setIsUnlocked(true);
      setPasswordInput('');
    } else {
      alert('كلمة المرور غير صحيحة');
      setPasswordInput('');
    }
  };

  if (!isUnlocked) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white flex items-center justify-center p-4">
        <div className="bg-slate-900 rounded-lg p-8 max-w-md w-full border border-orange-600">
          <div className="flex items-center justify-center mb-6">
            <Lock className="h-12 w-12 text-orange-600" />
          </div>
          <h1 className="text-2xl font-bold text-center mb-2">لوحة التحكم الآمنة</h1>
          <p className="text-gray-400 text-center mb-6">أدخل كلمة المرور للوصول إلى الإدارة</p>
          
          <form onSubmit={handlePasswordSubmit} className="space-y-4">
            <input
              type="password"
              placeholder="كلمة المرور"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-orange-600"
            />
            <Button
              type="submit"
              className="w-full bg-orange-600 hover:bg-orange-700"
            >
              الدخول
            </Button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">
            لوحة <span className="text-orange-600">التحكم</span>
          </h1>
          <p className="text-gray-400">إدارة الملفات الصوتية والإعدادات</p>
        </div>

        {/* Upload Section */}
        <div className="bg-slate-900 rounded-lg p-8 border border-slate-800 mb-8">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Upload className="h-6 w-6 text-orange-600" />
            تحميل ملف صوتي جديد
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold mb-2">العنوان</label>
              <input
                type="text"
                placeholder="مثال: قصيدة نانا"
                className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-orange-600"
              />
            </div>

            <div>
              <label className="block text-sm font-bold mb-2">النوع</label>
              <select className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-orange-600">
                <option value="poem">قصيدة</option>
                <option value="music">موسيقى</option>
                <option value="quran">قرآن</option>
                <option value="other">أخرى</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold mb-2">الوصف</label>
              <textarea
                placeholder="وصف الملف الصوتي"
                className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-orange-600"
                rows={3}
              />
            </div>

            <div>
              <label className="block text-sm font-bold mb-2">الملف الصوتي</label>
              <input
                type="file"
                accept="audio/*"
                className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-orange-600"
              />
            </div>
          </div>

          <Button className="mt-6 bg-orange-600 hover:bg-orange-700 w-full md:w-auto">
            <Upload className="h-5 w-5 ml-2" />
            تحميل الملف
          </Button>
        </div>

        {/* Audio Content List */}
        <div className="bg-slate-900 rounded-lg p-8 border border-slate-800">
          <h2 className="text-2xl font-bold mb-6">الملفات الصوتية المحفوظة</h2>

          <div className="space-y-4">
            {/* Sample Audio Item */}
            <div className="bg-slate-800 rounded-lg p-4 flex items-center justify-between hover:bg-slate-700 transition-colors">
              <div className="flex items-center gap-4 flex-1">
                <Music className="h-8 w-8 text-orange-600" />
                <div>
                  <h3 className="font-bold">قصيدة أبوظبي والإبداع</h3>
                  <p className="text-sm text-gray-400">قصيدة • 3:45 دقيقة</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button className="bg-orange-600 hover:bg-orange-700 px-4 py-2 rounded-lg flex items-center gap-2 transition-colors">
                  <Star className="h-4 w-4" />
                  افتراضي
                </button>
                <button className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg flex items-center gap-2 transition-colors">
                  <Trash2 className="h-4 w-4" />
                  حذف
                </button>
              </div>
            </div>

            {/* Empty State */}
            <div className="text-center py-12 border-2 border-dashed border-slate-700 rounded-lg">
              <FileAudio className="h-12 w-12 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">لا توجد ملفات صوتية أخرى</p>
            </div>
          </div>
        </div>

        {/* Settings Section */}
        <div className="bg-slate-900 rounded-lg p-8 border border-slate-800 mt-8">
          <h2 className="text-2xl font-bold mb-6">الإعدادات</h2>

          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold">التشغيل التلقائي</h3>
                <p className="text-sm text-gray-400">تشغيل الموسيقى تلقائياً عند فتح الموقع</p>
              </div>
              <input
                type="checkbox"
                defaultChecked
                className="w-6 h-6 accent-orange-600"
              />
            </div>

            <div>
              <label className="block font-bold mb-2">مستوى الصوت</label>
              <input
                type="range"
                min="0"
                max="100"
                defaultValue="30"
                className="w-full accent-orange-600"
              />
            </div>

            <Button className="bg-orange-600 hover:bg-orange-700">
              حفظ الإعدادات
            </Button>
          </div>
        </div>

        {/* Logout */}
        <div className="mt-8 text-center">
          <Button
            variant="outline"
            className="border-orange-600 text-orange-600 hover:bg-orange-600/10"
            onClick={() => {
              setIsUnlocked(false);
              setPasswordInput('');
              window.location.href = '/dashboard';
            }}
          >
            تسجيل الخروج من لوحة التحكم
          </Button>
        </div>
      </div>
    </div>
  );
}
