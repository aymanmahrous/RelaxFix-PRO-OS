import { Shield, Lock, Eye, Zap, CheckCircle, Award } from 'lucide-react';

/**
 * Trust and Security Page - Assure customers about data protection
 */
export default function TrustSecurity() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16 pt-8">
          <h1 className="text-5xl font-bold mb-4">
            الأمان <span className="text-orange-600">والخصوصية</span>
          </h1>
          <p className="text-xl text-gray-400">نحن نحمي بيانات عملائنا بأعلى معايير الأمان العالمية</p>
        </div>

        {/* Trust Badges */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          <div className="bg-slate-900 rounded-lg p-8 border border-orange-600/30 text-center">
            <Lock className="h-12 w-12 text-orange-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">تشفير SSL 256-bit</h3>
            <p className="text-gray-400">جميع البيانات مشفرة بأعلى معايير الأمان</p>
          </div>

          <div className="bg-slate-900 rounded-lg p-8 border border-orange-600/30 text-center">
            <Shield className="h-12 w-12 text-orange-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">حماية PCI DSS</h3>
            <p className="text-gray-400">معايير دولية لحماية بيانات البطاقات البنكية</p>
          </div>

          <div className="bg-slate-900 rounded-lg p-8 border border-orange-600/30 text-center">
            <Eye className="h-12 w-12 text-orange-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">سياسة الخصوصية الكاملة</h3>
            <p className="text-gray-400">شفافية تامة في استخدام بيانات العملاء</p>
          </div>
        </div>

        {/* Security Features */}
        <div className="bg-slate-900 rounded-lg p-8 border border-slate-800 mb-16">
          <h2 className="text-3xl font-bold mb-8">ميزات الأمان</h2>

          <div className="space-y-6">
            {[
              {
                icon: Lock,
                title: 'تشفير البيانات الحساسة',
                desc: 'جميع بيانات البطاقات البنكية والمعلومات الشخصية مشفرة بأعلى معايير الأمان'
              },
              {
                icon: Zap,
                title: 'مراقبة 24/7',
                desc: 'نظام مراقبة مستمر للكشف عن أي محاولات اختراق أو نشاط مريب'
              },
              {
                icon: CheckCircle,
                title: 'نسخ احتياطية يومية',
                desc: 'نسخ احتياطية تلقائية لجميع البيانات لضمان عدم فقدانها'
              },
              {
                icon: Award,
                title: 'شهادات دولية',
                desc: 'معتمدون من قبل أفضل شركات الأمان السيبراني العالمية'
              }
            ].map((feature, idx) => (
              <div key={idx} className="flex gap-4 p-4 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition-colors">
                <feature.icon className="h-8 w-8 text-orange-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold mb-2">{feature.title}</h3>
                  <p className="text-gray-400">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Privacy Policy */}
        <div className="bg-slate-900 rounded-lg p-8 border border-slate-800 mb-16">
          <h2 className="text-3xl font-bold mb-8">سياسة الخصوصية</h2>

          <div className="space-y-6 text-gray-300">
            <div>
              <h3 className="text-xl font-bold text-orange-600 mb-3">1. جمع البيانات</h3>
              <p>نجمع فقط البيانات الضرورية لتقديم الخدمة (الاسم، البريد الإلكتروني، رقم الهاتف). لا نجمع بيانات إضافية بدون موافقتك الصريحة.</p>
            </div>

            <div>
              <h3 className="text-xl font-bold text-orange-600 mb-3">2. استخدام البيانات</h3>
              <p>تُستخدم بيانات العملاء فقط لـ:
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>تقديم الخدمات المطلوبة</li>
                <li>إرسال الإشعارات والتحديثات</li>
                <li>تحسين جودة الخدمة</li>
                <li>الامتثال للقوانين واللوائح</li>
              </ul>
              </p>
            </div>

            <div>
              <h3 className="text-xl font-bold text-orange-600 mb-3">3. حماية البيانات</h3>
              <p>نستخدم أحدث تقنيات التشفير والحماية لضمان سلامة بيانات العملاء. جميع الموظفين يتلقون تدريباً على أمان البيانات.</p>
            </div>

            <div>
              <h3 className="text-xl font-bold text-orange-600 mb-3">4. حقوق العملاء</h3>
              <p>لك الحق في:
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>الوصول إلى بيانات حسابك</li>
                <li>تصحيح أي معلومات غير صحيحة</li>
                <li>حذف حسابك وبيانات</li>
                <li>الاعتراض على معالجة بيانات</li>
              </ul>
              </p>
            </div>

            <div>
              <h3 className="text-xl font-bold text-orange-600 mb-3">5. الاتصال بنا</h3>
              <p>إذا كان لديك أي استفسارات حول الخصوصية أو الأمان، تواصل معنا على:
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>البريد: privacy@relaxfix.com</li>
                <li>الهاتف: +971588259848</li>
                <li>واتس أب: +971588259848</li>
              </ul>
              </p>
            </div>
          </div>
        </div>

        {/* Certifications */}
        <div className="bg-slate-900 rounded-lg p-8 border border-slate-800">
          <h2 className="text-3xl font-bold mb-8">الشهادات والمعايير</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { name: 'ISO 27001', desc: 'معيار الأمان المعلوماتي الدولي' },
              { name: 'GDPR', desc: 'قانون حماية البيانات الأوروبي' },
              { name: 'PCI DSS', desc: 'معيار أمان بيانات البطاقات' },
              { name: 'SOC 2', desc: 'معيار الأمان والموثوقية' }
            ].map((cert, idx) => (
              <div key={idx} className="bg-slate-800/50 rounded-lg p-4 border border-orange-600/20">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="h-5 w-5 text-orange-600" />
                  <h3 className="font-bold">{cert.name}</h3>
                </div>
                <p className="text-gray-400 text-sm">{cert.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
