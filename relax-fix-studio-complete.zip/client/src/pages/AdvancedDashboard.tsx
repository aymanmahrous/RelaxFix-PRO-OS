import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { BarChart3, TrendingUp, Zap, FileText, Download, Settings, LogOut } from 'lucide-react';

/**
 * Advanced Dashboard - Comprehensive user control panel
 */
export default function AdvancedDashboard() {
  const [activeSection, setActiveSection] = useState<'overview' | 'projects' | 'billing' | 'settings'>('overview');

  const stats = [
    { label: 'إجمالي العملات', value: '500', icon: Zap, color: 'orange' },
    { label: 'المشاريع', value: '12', icon: FileText, color: 'blue' },
    { label: 'الفيديوهات المولدة', value: '45', icon: TrendingUp, color: 'green' },
    { label: 'التصاميم', value: '28', icon: BarChart3, color: 'purple' }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <div className="bg-slate-900 border-b border-slate-800 p-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <h1 className="text-3xl font-bold">لوحة التحكم</h1>
          <div className="flex items-center gap-4">
            <Button variant="outline" className="border-slate-700">
              <Settings className="h-4 w-4 ml-2" />
              الإعدادات
            </Button>
            <Button variant="outline" className="border-red-600 text-red-600">
              <LogOut className="h-4 w-4 ml-2" />
              تسجيل خروج
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            const colorClass = {
              orange: 'from-orange-600/20 to-orange-600/5 border-orange-600/50',
              blue: 'from-blue-600/20 to-blue-600/5 border-blue-600/50',
              green: 'from-green-600/20 to-green-600/5 border-green-600/50',
              purple: 'from-purple-600/20 to-purple-600/5 border-purple-600/50'
            }[stat.color];

            return (
              <div key={idx} className={`bg-gradient-to-br ${colorClass} rounded-lg p-6 border`}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm mb-1">{stat.label}</p>
                    <p className="text-3xl font-bold">{stat.value}</p>
                  </div>
                  <Icon className="h-8 w-8 opacity-50" />
                </div>
              </div>
            );
          })}
        </div>

        {/* Navigation Tabs */}
        <div className="flex gap-2 mb-8 border-b border-slate-800">
          {[
            { id: 'overview', label: 'نظرة عامة' },
            { id: 'projects', label: 'المشاريع' },
            { id: 'billing', label: 'الفواتير' },
            { id: 'settings', label: 'الإعدادات' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveSection(tab.id as any)}
              className={`px-4 py-3 border-b-2 transition-colors ${
                activeSection === tab.id
                  ? 'border-orange-600 text-orange-600'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Overview Section */}
        {activeSection === 'overview' && (
          <div className="space-y-6">
            {/* Recent Activity */}
            <div className="bg-slate-900 rounded-lg p-6 border border-slate-800">
              <h2 className="text-xl font-bold mb-4">النشاط الأخير</h2>
              <div className="space-y-3">
                {[
                  { action: 'تم إنشاء فيديو جديد', time: 'قبل ساعة', icon: '🎥' },
                  { action: 'تم إنشاء تصميم جديد', time: 'قبل 3 ساعات', icon: '🎨' },
                  { action: 'تم تحديث الاشتراك', time: 'قبل يوم', icon: '💳' }
                ].map((activity, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{activity.icon}</span>
                      <span>{activity.action}</span>
                    </div>
                    <span className="text-sm text-gray-400">{activity.time}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-slate-900 rounded-lg p-6 border border-slate-800">
              <h2 className="text-xl font-bold mb-4">إجراءات سريعة</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button className="bg-orange-600 hover:bg-orange-700 py-3">
                  ✨ إنشاء تصميم جديد
                </Button>
                <Button className="bg-orange-600 hover:bg-orange-700 py-3">
                  🎥 توليد فيديو
                </Button>
                <Button className="bg-orange-600 hover:bg-orange-700 py-3">
                  💳 ترقية الاشتراك
                </Button>
                <Button className="bg-orange-600 hover:bg-orange-700 py-3">
                  📊 عرض الإحصائيات
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Projects Section */}
        {activeSection === 'projects' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">مشاريعي</h2>
              <Button className="bg-orange-600 hover:bg-orange-700">
                + مشروع جديد
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map(project => (
                <div key={project} className="bg-slate-900 rounded-lg overflow-hidden border border-slate-800 hover:border-orange-600/50 transition-colors">
                  <div className="h-32 bg-gradient-to-br from-orange-600/20 to-orange-600/5"></div>
                  <div className="p-4">
                    <h3 className="font-bold mb-2">المشروع {project}</h3>
                    <p className="text-sm text-gray-400 mb-4">تم الإنشاء قبل أسبوع</p>
                    <div className="flex gap-2">
                      <Button variant="outline" className="flex-1 border-slate-700 text-sm">
                        تعديل
                      </Button>
                      <Button variant="outline" className="flex-1 border-slate-700 text-sm">
                        حذف
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Billing Section */}
        {activeSection === 'billing' && (
          <div className="space-y-6">
            <div className="bg-slate-900 rounded-lg p-6 border border-slate-800">
              <h2 className="text-xl font-bold mb-4">الفواتير والدفع</h2>

              <div className="space-y-4">
                {/* Current Plan */}
                <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="font-bold">خطة Pro الحالية</h3>
                      <p className="text-sm text-gray-400">تجديد في 2026-06-05</p>
                    </div>
                    <span className="text-2xl font-bold text-orange-600">$79</span>
                  </div>
                  <Button className="w-full bg-orange-600 hover:bg-orange-700">
                    ترقية الخطة
                  </Button>
                </div>

                {/* Recent Invoices */}
                <div>
                  <h3 className="font-bold mb-3">الفواتير الأخيرة</h3>
                  <div className="space-y-2">
                    {[
                      { date: '2026-05-05', amount: '$79.00', status: 'مدفوع' },
                      { date: '2026-04-05', amount: '$79.00', status: 'مدفوع' },
                      { date: '2026-03-05', amount: '$79.00', status: 'مدفوع' }
                    ].map((invoice, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                        <div>
                          <p className="font-bold">{invoice.date}</p>
                          <p className="text-sm text-gray-400">{invoice.status}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-bold">{invoice.amount}</span>
                          <Button variant="outline" className="border-slate-700 p-2 h-auto">
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Settings Section */}
        {activeSection === 'settings' && (
          <div className="space-y-6">
            <div className="bg-slate-900 rounded-lg p-6 border border-slate-800">
              <h2 className="text-xl font-bold mb-4">الإعدادات</h2>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                  <div>
                    <h3 className="font-bold">المصادقة الثنائية</h3>
                    <p className="text-sm text-gray-400">حماية إضافية لحسابك</p>
                  </div>
                  <Button variant="outline" className="border-slate-700">
                    تفعيل
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                  <div>
                    <h3 className="font-bold">الإشعارات</h3>
                    <p className="text-sm text-gray-400">تلقي تنبيهات عن النشاط</p>
                  </div>
                  <input type="checkbox" defaultChecked className="w-5 h-5" />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                  <div>
                    <h3 className="font-bold">النسخ الاحتياطية التلقائية</h3>
                    <p className="text-sm text-gray-400">نسخة احتياطية يومية</p>
                  </div>
                  <input type="checkbox" defaultChecked className="w-5 h-5" />
                </div>

                <Button variant="outline" className="w-full border-red-600 text-red-600 mt-6">
                  حذف الحساب
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
