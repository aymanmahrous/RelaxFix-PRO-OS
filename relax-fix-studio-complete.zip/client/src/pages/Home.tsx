import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { ArrowRight, Zap, Users, TrendingUp, Shield, Smartphone, Phone, Mail, Music, Pause, Play, Film, Sparkles, Clapperboard } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLanguage } from "@/contexts/LanguageContext";

/**
 * Home Page - Landing Page for Relax Fix Studio + Cinema AI
 * Premium design with live backgrounds, Abu Dhabi landmarks, and music
 */
export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioRef, setAudioRef] = useState<HTMLAudioElement | null>(null);
  const [showPoemModal, setShowPoemModal] = useState(false);

  // Initialize audio
  useEffect(() => {
    const audio = new Audio();
    audio.loop = true;
    audio.volume = 0.3;
    audio.src = '/audio/poem.mp3';
    audio.onerror = () => {
      audio.src = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3';
    };
    setAudioRef(audio);
    return () => {
      audio.pause();
      audio.src = '';
    };
  }, []);

  const toggleMusic = () => {
    if (audioRef) {
      if (isPlaying) {
        audioRef.pause();
      } else {
        audioRef.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Music Player Button */}
      <button
        onClick={toggleMusic}
        className="fixed bottom-8 right-8 z-40 bg-orange-600 hover:bg-orange-700 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all"
        title={isPlaying ? (language === 'ar' ? "إيقاف الموسيقى" : "Stop Music") : (language === 'ar' ? "تشغيل الموسيقى" : "Play Music")}
      >
        {isPlaying ? (
          <Pause className="h-6 w-6" />
        ) : (
          <Music className="h-6 w-6" />
        )}
      </button>

      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold">
            <span className="text-orange-600">Relax Fix</span>
            <span className="text-white"> Studio</span>
          </div>
          <div className="flex gap-4 items-center">
            <div className="text-sm text-gray-400 flex items-center gap-2">
              <span>by Ayman Mahrous</span>
              <span className="text-orange-600">ما شاء الله لا قوة إلا بالله</span>
            </div>
            
            {/* Language Switcher */}
            <div className="flex gap-2 border border-gray-600 rounded-lg p-1">
              <button
                onClick={() => setLanguage('ar')}
                className={`px-3 py-1 rounded transition-colors ${
                  language === 'ar'
                    ? 'bg-orange-600 text-white'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                العربية
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-3 py-1 rounded transition-colors ${
                  language === 'en'
                    ? 'bg-orange-600 text-white'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                English
              </button>
            </div>

            {!isAuthenticated ? (
              <>
                <Button
                  variant="outline"
                  onClick={() => (window.location.href = "/dashboard")}
                >
                  {t('nav.login')}
                </Button>
                <Button
                  className="bg-orange-600 hover:bg-orange-700"
                  onClick={() => (window.location.href = "/dashboard")}
                >
                  {t('nav.start')}
                </Button>
              </>
            ) : (
              <Button
                className="bg-orange-600 hover:bg-orange-700"
                onClick={() => (window.location.href = "/dashboard")}
              >
                {t('nav.dashboard')}
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section with Animated Background */}
      <section className="pt-32 pb-20 px-4 text-center relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-orange-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
        </div>

        <div className="max-w-4xl mx-auto space-y-8">
          {/* Main Title with Animation */}
          <div className="space-y-4">
            <h1 className="text-5xl md:text-7xl font-bold leading-tight animate-fade-in">
              {language === 'ar' ? (
                <>
                  منصة <span className="text-orange-600 drop-shadow-lg">Relax Fix</span>
                  <br />
                  <span className="text-gray-300">للإنتاج الإعلاني السينمائي</span>
                </>
              ) : (
                <>
                  <span className="text-orange-600 drop-shadow-lg">Relax Fix</span> Studio
                  <br />
                  <span className="text-gray-300">Cinematic Ad Production Platform</span>
                </>
              )}
            </h1>
          </div>

          {/* Description */}
          <p className="text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed">
            {language === 'ar'
              ? 'أنتج إعلانات احترافية بالذكاء الاصطناعي، أدر مشاريعك، وتابع عملائك من لوحة تحكم واحدة متكاملة'
              : 'Create professional ads with AI, manage your projects, and track your clients from one integrated dashboard'}
          </p>

          {/* CTA Buttons */}
          <div className="flex gap-4 justify-center flex-wrap pt-4">
            <Button
              size="lg"
              className="bg-orange-600 hover:bg-orange-700 text-lg px-8 py-6 shadow-lg hover:shadow-xl transition-all"
              onClick={() => (window.location.href = "/dashboard")}
            >
              {t('home.cta.start')} <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-lg px-8 py-6 border-orange-600 text-orange-600 hover:bg-orange-600/10"
              onClick={() => setShowPoemModal(true)}
            >
              {language === 'ar' ? 'اسمع القصيدة' : 'Listen to Poem'}
            </Button>
          </div>

          {/* Stats with Animation */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16 pt-16 border-t border-slate-800">
            <div className="text-center hover:scale-105 transition-transform">
              <div className="text-4xl font-bold text-orange-600">10+</div>
              <p className="text-gray-400 mt-2">{language === 'ar' ? 'خدمات متخصصة' : 'Specialized Services'}</p>
            </div>
            <div className="text-center hover:scale-105 transition-transform">
              <div className="text-4xl font-bold text-orange-600">3</div>
              <p className="text-gray-400 mt-2">{language === 'ar' ? 'خطط اشتراك' : 'Subscription Plans'}</p>
            </div>
            <div className="text-center hover:scale-105 transition-transform">
              <div className="text-4xl font-bold text-orange-600">24/7</div>
              <p className="text-gray-400 mt-2">{language === 'ar' ? 'دعم العملاء' : 'Customer Support'}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-4 bg-slate-900/50 border-t border-slate-800">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16">
            {language === 'ar' ? 'خدماتنا المتخصصة' : 'Our Specialized Services'}
          </h2>

          {/* Relax Fix Services */}
          <div className="mb-20">
            <h3 className="text-2xl font-bold text-orange-600 mb-8 text-center">
              {language === 'ar' ? 'منصة Relax Fix' : 'Relax Fix Platform'}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Design Editor */}
              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-8 hover:border-orange-600 transition-colors">
                <Zap className="h-12 w-12 text-orange-600 mb-4" />
                <h3 className="text-2xl font-bold mb-4">
                  {language === 'ar' ? 'محرر التصميم' : 'Design Editor'}
                </h3>
                <p className="text-gray-400 mb-6">
                  {language === 'ar'
                    ? 'صمم إعلانات احترافية بسهولة باستخدام أدوات متقدمة'
                    : 'Design professional ads easily with advanced tools'}
                </p>
                <Button
                  variant="outline"
                  className="w-full border-orange-600 text-orange-600 hover:bg-orange-600/10"
                  onClick={() => (window.location.href = "/design")}
                >
                  {language === 'ar' ? 'جرب الآن' : 'Try Now'}
                </Button>
              </div>

              {/* Video Generator */}
              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-8 hover:border-orange-600 transition-colors">
                <Users className="h-12 w-12 text-orange-600 mb-4" />
                <h3 className="text-2xl font-bold mb-4">
                  {language === 'ar' ? 'مولد الفيديوهات' : 'Video Generator'}
                </h3>
                <p className="text-gray-400 mb-6">
                  {language === 'ar'
                    ? 'أنتج فيديوهات سينمائية بالذكاء الاصطناعي'
                    : 'Produce cinematic videos with AI'}
                </p>
                <Button
                  variant="outline"
                  className="w-full border-orange-600 text-orange-600 hover:bg-orange-600/10"
                  onClick={() => (window.location.href = "/video")}
                >
                  {language === 'ar' ? 'جرب الآن' : 'Try Now'}
                </Button>
              </div>

              {/* Dashboard */}
              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-8 hover:border-orange-600 transition-colors">
                <TrendingUp className="h-12 w-12 text-orange-600 mb-4" />
                <h3 className="text-2xl font-bold mb-4">
                  {language === 'ar' ? 'لوحة التحكم' : 'Control Panel'}
                </h3>
                <p className="text-gray-400 mb-6">
                  {language === 'ar'
                    ? 'أدر مشاريعك وعملائك من لوحة تحكم متكاملة'
                    : 'Manage your projects and clients from one dashboard'}
                </p>
                <Button
                  variant="outline"
                  className="w-full border-orange-600 text-orange-600 hover:bg-orange-600/10"
                  onClick={() => (window.location.href = "/dashboard")}
                >
                  {language === 'ar' ? 'ادخل الآن' : 'Enter Now'}
                </Button>
              </div>
            </div>
          </div>

          {/* Cinema AI Services */}
          <div className="border-t border-slate-700 pt-20">
            <h3 className="text-2xl font-bold text-orange-600 mb-8 text-center">
              {language === 'ar' ? 'خدمات Cinema AI المتقدمة' : 'Cinema AI Advanced Services'}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Script Generation */}
              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-8 hover:border-orange-600 transition-colors">
                <Clapperboard className="h-12 w-12 text-orange-600 mb-4" />
                <h3 className="text-2xl font-bold mb-4">
                  {language === 'ar' ? 'توليد السكريبتات' : 'Script Generation'}
                </h3>
                <p className="text-gray-400 mb-6">
                  {language === 'ar'
                    ? 'إنشاء سيناريوهات سينمائية احترافية بالذكاء الاصطناعي'
                    : 'Create professional cinematic scripts with AI'}
                </p>
                <Button
                  variant="outline"
                  className="w-full border-orange-600 text-orange-600 hover:bg-orange-600/10"
                  onClick={() => (window.location.href = "/dashboard")}
                >
                  {language === 'ar' ? 'ابدأ الآن' : 'Start Now'}
                </Button>
              </div>

              {/* Scene Manager */}
              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-8 hover:border-orange-600 transition-colors">
                <Film className="h-12 w-12 text-orange-600 mb-4" />
                <h3 className="text-2xl font-bold mb-4">
                  {language === 'ar' ? 'مدير المشاهد' : 'Scene Manager'}
                </h3>
                <p className="text-gray-400 mb-6">
                  {language === 'ar'
                    ? 'تحرير وتنظيم المشاهد مع التحكم الكامل'
                    : 'Edit and organize scenes with full control'}
                </p>
                <Button
                  variant="outline"
                  className="w-full border-orange-600 text-orange-600 hover:bg-orange-600/10"
                  onClick={() => (window.location.href = "/dashboard")}
                >
                  {language === 'ar' ? 'جرب الآن' : 'Try Now'}
                </Button>
              </div>

              {/* Visual Effects */}
              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-8 hover:border-orange-600 transition-colors">
                <Sparkles className="h-12 w-12 text-orange-600 mb-4" />
                <h3 className="text-2xl font-bold mb-4">
                  {language === 'ar' ? 'المؤثرات البصرية' : 'Visual Effects'}
                </h3>
                <p className="text-gray-400 mb-6">
                  {language === 'ar'
                    ? 'إضافة مؤثرات بصرية احترافية وتأثيرات متقدمة'
                    : 'Add professional visual effects and transitions'}
                </p>
                <Button
                  variant="outline"
                  className="w-full border-orange-600 text-orange-600 hover:bg-orange-600/10"
                  onClick={() => (window.location.href = "/dashboard")}
                >
                  {language === 'ar' ? 'استكشف الآن' : 'Explore Now'}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Abu Dhabi Landmarks Section */}
      <section className="py-20 px-4 border-t border-slate-800">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16">
            {language === 'ar' ? 'معالم أبو ظبي الخلابة' : 'Beautiful Abu Dhabi Landmarks'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Corniche */}
            <div className="group relative overflow-hidden rounded-lg h-64 cursor-pointer">
              <img
                src="https://images.unsplash.com/photo-1518684029980-cf91eb079b1d?w=500&h=300&fit=crop"
                alt={language === 'ar' ? 'الكورنيش' : 'Corniche'}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-6">
                <h3 className="text-xl font-bold">
                  {language === 'ar' ? 'الكورنيش' : 'Corniche'}
                </h3>
              </div>
            </div>

            {/* Grand Mosque */}
            <div className="group relative overflow-hidden rounded-lg h-64 cursor-pointer">
              <img
                src="https://images.unsplash.com/photo-1570158108519-271a1a3cc84d?w=500&h=300&fit=crop"
                alt={language === 'ar' ? 'الجامع الكبير' : 'Grand Mosque'}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-6">
                <h3 className="text-xl font-bold">
                  {language === 'ar' ? 'الجامع الكبير' : 'Grand Mosque'}
                </h3>
              </div>
            </div>

            {/* Yas Island */}
            <div className="group relative overflow-hidden rounded-lg h-64 cursor-pointer">
              <img
                src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=500&h=300&fit=crop"
                alt={language === 'ar' ? 'جزيرة ياس' : 'Yas Island'}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-6">
                <h3 className="text-xl font-bold">
                  {language === 'ar' ? 'جزيرة ياس' : 'Yas Island'}
                </h3>
              </div>
            </div>

            {/* Emirates Palace */}
            <div className="group relative overflow-hidden rounded-lg h-64 cursor-pointer">
              <img
                src="https://images.unsplash.com/photo-1518684029980-cf91eb079b1d?w=500&h=300&fit=crop"
                alt={language === 'ar' ? 'قصر الوحدة' : 'Emirates Palace'}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-6">
                <h3 className="text-xl font-bold">
                  {language === 'ar' ? 'قصر الوحدة' : 'Emirates Palace'}
                </h3>
              </div>
            </div>

            {/* Al Jahili Fort */}
            <div className="group relative overflow-hidden rounded-lg h-64 cursor-pointer">
              <img
                src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=500&h=300&fit=crop"
                alt={language === 'ar' ? 'حصن الجاهلي' : 'Al Jahili Fort'}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-6">
                <h3 className="text-xl font-bold">
                  {language === 'ar' ? 'حصن الجاهلي' : 'Al Jahili Fort'}
                </h3>
              </div>
            </div>

            {/* Abu Dhabi Beach */}
            <div className="group relative overflow-hidden rounded-lg h-64 cursor-pointer">
              <img
                src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=500&h=300&fit=crop"
                alt={language === 'ar' ? 'شاطئ أبو ظبي' : 'Abu Dhabi Beach'}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-6">
                <h3 className="text-xl font-bold">
                  {language === 'ar' ? 'شاطئ أبو ظبي' : 'Abu Dhabi Beach'}
                </h3>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 px-4 bg-slate-900/50 border-t border-slate-800">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16">
            {language === 'ar' ? 'اختر خطتك' : 'Choose Your Plan'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Starter */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-8 hover:border-orange-600 transition-colors">
              <h3 className="text-2xl font-bold mb-4">
                {language === 'ar' ? 'ستارتر' : 'Starter'}
              </h3>
              <div className="text-4xl font-bold text-orange-600 mb-6">$29<span className="text-lg text-gray-400">/mo</span></div>
              <ul className="space-y-3 mb-8 text-gray-400">
                <li>✓ {language === 'ar' ? '5 مشاريع' : '5 Projects'}</li>
                <li>✓ {language === 'ar' ? '10 GB تخزين' : '10 GB Storage'}</li>
                <li>✓ {language === 'ar' ? 'دعم البريد الإلكتروني' : 'Email Support'}</li>
              </ul>
              <Button className="w-full bg-orange-600 hover:bg-orange-700">
                {language === 'ar' ? 'اختر الآن' : 'Choose Now'}
              </Button>
            </div>

            {/* Pro */}
            <div className="bg-slate-800/50 border border-orange-600 rounded-lg p-8 relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-orange-600 px-4 py-1 rounded-full text-sm font-bold">
                {language === 'ar' ? 'الأفضل' : 'BEST'}
              </div>
              <h3 className="text-2xl font-bold mb-4">
                {language === 'ar' ? 'برو' : 'Pro'}
              </h3>
              <div className="text-4xl font-bold text-orange-600 mb-6">$79<span className="text-lg text-gray-400">/mo</span></div>
              <ul className="space-y-3 mb-8 text-gray-400">
                <li>✓ {language === 'ar' ? 'مشاريع غير محدودة' : 'Unlimited Projects'}</li>
                <li>✓ {language === 'ar' ? '100 GB تخزين' : '100 GB Storage'}</li>
                <li>✓ {language === 'ar' ? 'دعم الأولوية' : 'Priority Support'}</li>
              </ul>
              <Button className="w-full bg-orange-600 hover:bg-orange-700">
                {language === 'ar' ? 'اختر الآن' : 'Choose Now'}
              </Button>
            </div>

            {/* Enterprise */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-8 hover:border-orange-600 transition-colors">
              <h3 className="text-2xl font-bold mb-4">
                {language === 'ar' ? 'إنتربرايز' : 'Enterprise'}
              </h3>
              <div className="text-4xl font-bold text-orange-600 mb-6">$199<span className="text-lg text-gray-400">/mo</span></div>
              <ul className="space-y-3 mb-8 text-gray-400">
                <li>✓ {language === 'ar' ? 'ميزات مخصصة' : 'Custom Features'}</li>
                <li>✓ {language === 'ar' ? 'تخزين غير محدود' : 'Unlimited Storage'}</li>
                <li>✓ {language === 'ar' ? 'دعم 24/7' : '24/7 Support'}</li>
              </ul>
              <Button className="w-full bg-orange-600 hover:bg-orange-700">
                {language === 'ar' ? 'اختر الآن' : 'Choose Now'}
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 px-4 border-t border-slate-800">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-8">
            {language === 'ar' ? 'تواصل معنا' : 'Contact Us'}
          </h2>
          <p className="text-xl text-gray-400 mb-12">
            {language === 'ar'
              ? 'هل لديك أسئلة؟ نحن هنا للمساعدة'
              : 'Have questions? We\'re here to help'}
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <a href="tel:+971588259848" className="flex items-center justify-center gap-4 bg-slate-800/50 border border-slate-700 rounded-lg p-6 hover:border-orange-600 transition-colors">
              <Phone className="h-8 w-8 text-orange-600" />
              <div className="text-left">
                <p className="text-gray-400">{language === 'ar' ? 'الهاتف' : 'Phone'}</p>
                <p className="text-lg font-bold">+971 58 825 9848</p>
              </div>
            </a>
            <a href="mailto:info@relaxfix.ae" className="flex items-center justify-center gap-4 bg-slate-800/50 border border-slate-700 rounded-lg p-6 hover:border-orange-600 transition-colors">
              <Mail className="h-8 w-8 text-orange-600" />
              <div className="text-left">
                <p className="text-gray-400">{language === 'ar' ? 'البريد الإلكتروني' : 'Email'}</p>
                <p className="text-lg font-bold">info@relaxfix.ae</p>
              </div>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-800 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-lg font-bold mb-4">
                <span className="text-orange-600">Relax Fix</span> Studio
              </h3>
              <p className="text-gray-400 text-sm">
                {language === 'ar'
                  ? 'منصة متكاملة للإنتاج الإعلاني السينمائي'
                  : 'Integrated platform for cinematic ad production'}
              </p>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">{language === 'ar' ? 'الخدمات' : 'Services'}</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="/design" className="hover:text-orange-600 transition-colors">{language === 'ar' ? 'محرر التصميم' : 'Design Editor'}</a></li>
                <li><a href="/video" className="hover:text-orange-600 transition-colors">{language === 'ar' ? 'مولد الفيديوهات' : 'Video Generator'}</a></li>
                <li><a href="/pricing" className="hover:text-orange-600 transition-colors">{language === 'ar' ? 'الأسعار' : 'Pricing'}</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">{language === 'ar' ? 'الشركة' : 'Company'}</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-orange-600 transition-colors">{language === 'ar' ? 'عن الشركة' : 'About Us'}</a></li>
                <li><a href="#" className="hover:text-orange-600 transition-colors">{language === 'ar' ? 'سياسة الخصوصية' : 'Privacy Policy'}</a></li>
                <li><a href="#" className="hover:text-orange-600 transition-colors">{language === 'ar' ? 'شروط الخدمة' : 'Terms of Service'}</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">{language === 'ar' ? 'تابعنا' : 'Follow Us'}</h4>
              <div className="flex gap-4">
                <a href="#" className="text-gray-400 hover:text-orange-600 transition-colors">Telegram</a>
                <a href="#" className="text-gray-400 hover:text-orange-600 transition-colors">WhatsApp</a>
              </div>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2026 Relax Fix Studio. {language === 'ar' ? 'جميع الحقوق محفوظة' : 'All rights reserved'}</p>
          </div>
        </div>
      </footer>

      {/* Poem Modal */}
      {showPoemModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={() => setShowPoemModal(false)}>
          <div className="bg-slate-900 rounded-lg p-8 max-w-2xl w-full border border-orange-600" onClick={(e) => e.stopPropagation()}>
            <h2 className="text-3xl font-bold mb-6 text-center text-orange-600">
              {language === 'ar' ? 'القصيدة' : 'The Poem'}
            </h2>
            <div className="text-center text-xl leading-relaxed mb-8 text-gray-300">
              {language === 'ar' ? (
                <>
                  <p className="mb-4">نانا يا نانا</p>
                  <p className="mb-4">أنتِ جمال الدنيا</p>
                  <p className="mb-4">في عينيك نور</p>
                  <p className="mb-4">ما أحلاكِ يا نانا</p>
                  <p className="mb-4">ملكة الأحلام</p>
                  <p className="mb-4">في قلبي تسكنين</p>
                  <p>يا أجمل أنثى</p>
                </>
              ) : (
                <>
                  <p className="mb-4">Nana, oh Nana</p>
                  <p className="mb-4">You are the beauty of the world</p>
                  <p className="mb-4">In your eyes there is light</p>
                  <p className="mb-4">How sweet you are, Nana</p>
                  <p className="mb-4">Queen of dreams</p>
                  <p className="mb-4">You dwell in my heart</p>
                  <p>Oh most beautiful woman</p>
                </>
              )}
            </div>
            <div className="flex gap-4 justify-center">
              <Button
                className="bg-orange-600 hover:bg-orange-700"
                onClick={() => toggleMusic()}
              >
                {isPlaying ? (
                  <>
                    <Pause className="mr-2 h-4 w-4" />
                    {language === 'ar' ? 'إيقاف' : 'Stop'}
                  </>
                ) : (
                  <>
                    <Play className="mr-2 h-4 w-4" />
                    {language === 'ar' ? 'تشغيل' : 'Play'}
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                className="border-orange-600 text-orange-600 hover:bg-orange-600/10"
                onClick={() => setShowPoemModal(false)}
              >
                {language === 'ar' ? 'إغلاق' : 'Close'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
