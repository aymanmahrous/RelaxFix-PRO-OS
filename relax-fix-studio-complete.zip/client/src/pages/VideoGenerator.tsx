import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Play, Zap, Clock, Sparkles, Upload } from 'lucide-react';

/**
 * Video Generator - AI-powered video creation (like Veo 3)
 */
export default function VideoGenerator() {
  const [script, setScript] = useState('');
  const [videoStyle, setVideoStyle] = useState('modern');
  const [duration, setDuration] = useState('15');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedVideos, setGeneratedVideos] = useState<any[]>([]);

  const styles = [
    { id: 'modern', name: 'حديث', icon: '✨' },
    { id: 'cinematic', name: 'سينمائي', icon: '🎬' },
    { id: 'animated', name: 'متحرك', icon: '🎨' },
    { id: 'documentary', name: 'وثائقي', icon: '📹' },
    { id: 'promotional', name: 'ترويجي', icon: '📢' },
    { id: 'educational', name: 'تعليمي', icon: '📚' },
  ];

  const handleGenerate = async () => {
    if (!script.trim()) {
      alert('يرجى إدخال النص أولاً');
      return;
    }

    setIsGenerating(true);

    // Simulate video generation
    setTimeout(() => {
      setGeneratedVideos([
        {
          id: 1,
          title: 'الفيديو المولد',
          duration: parseInt(duration),
          style: videoStyle,
          status: 'completed',
          coinsUsed: parseInt(duration) * 2,
          thumbnail: 'https://via.placeholder.com/300x200?text=Generated+Video'
        }
      ]);
      setIsGenerating(false);
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-12 pt-8">
          <h1 className="text-5xl font-bold mb-4">
            مولد <span className="text-orange-600">الفيديوهات</span> بالذكاء الاصطناعي
          </h1>
          <p className="text-xl text-gray-400">حول نصك إلى فيديو احترافي في ثوان</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Input Section */}
          <div className="lg:col-span-2">
            <div className="bg-slate-900 rounded-lg p-8 border border-slate-800">
              <h2 className="text-2xl font-bold mb-6">أنشئ فيديوك</h2>

              {/* Script Input */}
              <div className="mb-6">
                <label className="block text-sm font-bold mb-2">النص أو السيناريو</label>
                <textarea
                  value={script}
                  onChange={(e) => setScript(e.target.value)}
                  placeholder="اكتب النص الذي تريد تحويله إلى فيديو..."
                  className="w-full h-40 px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-orange-600 resize-none"
                />
                <p className="text-xs text-gray-400 mt-2">
                  {script.length} / 5000 حرف
                </p>
              </div>

              {/* Style Selection */}
              <div className="mb-6">
                <label className="block text-sm font-bold mb-3">أسلوب الفيديو</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {styles.map(style => (
                    <button
                      key={style.id}
                      onClick={() => setVideoStyle(style.id)}
                      className={`p-4 rounded-lg transition-all text-center ${
                        videoStyle === style.id
                          ? 'bg-orange-600 border-2 border-orange-500'
                          : 'bg-slate-800 border border-slate-700 hover:border-orange-600/50'
                      }`}
                    >
                      <div className="text-2xl mb-2">{style.icon}</div>
                      <div className="text-sm font-bold">{style.name}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Duration */}
              <div className="mb-6">
                <label className="block text-sm font-bold mb-2">مدة الفيديو</label>
                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min="5"
                    max="60"
                    step="5"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    className="flex-1 accent-orange-600"
                  />
                  <div className="text-right">
                    <div className="text-2xl font-bold text-orange-600">{duration}</div>
                    <div className="text-xs text-gray-400">ثانية</div>
                  </div>
                </div>
              </div>

              {/* Cost Estimate */}
              <div className="bg-slate-800/50 rounded-lg p-4 mb-6 border border-slate-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-orange-600" />
                    <span className="font-bold">تكلفة التوليد المقدرة</span>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-orange-600">{parseInt(duration) * 2}</div>
                    <div className="text-xs text-gray-400">عملة</div>
                  </div>
                </div>
              </div>

              {/* Generate Button */}
              <Button
                onClick={handleGenerate}
                disabled={isGenerating || !script.trim()}
                className="w-full bg-orange-600 hover:bg-orange-700 disabled:opacity-50 py-3 text-lg"
              >
                {isGenerating ? (
                  <>
                    <Clock className="h-5 w-5 ml-2 animate-spin" />
                    جاري التوليد...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-5 w-5 ml-2" />
                    توليد الفيديو
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Info Section */}
          <div className="space-y-6">
            {/* Quick Tips */}
            <div className="bg-slate-900 rounded-lg p-6 border border-slate-800">
              <h3 className="text-lg font-bold mb-4">نصائح للحصول على أفضل النتائج</h3>
              <ul className="space-y-3 text-sm text-gray-300">
                <li className="flex gap-2">
                  <span className="text-orange-600">✓</span>
                  <span>استخدم جملاً واضحة وموجزة</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-orange-600">✓</span>
                  <span>أضف تفاصيل عن المشاهد المطلوبة</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-orange-600">✓</span>
                  <span>حدد الأسلوب المناسب للمحتوى</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-orange-600">✓</span>
                  <span>تجنب النصوص الطويلة جداً</span>
                </li>
              </ul>
            </div>

            {/* Credits Info */}
            <div className="bg-gradient-to-br from-orange-600/20 to-orange-600/5 rounded-lg p-6 border border-orange-600/50">
              <h3 className="text-lg font-bold mb-3">عملاتك المتاحة</h3>
              <div className="text-3xl font-bold text-orange-600 mb-2">500</div>
              <p className="text-sm text-gray-300 mb-4">
                كل فيديو بـ 15 ثانية = 30 عملة
              </p>
              <Button variant="outline" className="w-full border-orange-600 text-orange-600">
                شراء عملات إضافية
              </Button>
            </div>
          </div>
        </div>

        {/* Generated Videos */}
        {generatedVideos.length > 0 && (
          <div className="mt-16">
            <h2 className="text-3xl font-bold mb-8">الفيديوهات المولدة</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {generatedVideos.map(video => (
                <div key={video.id} className="bg-slate-900 rounded-lg overflow-hidden border border-slate-800 hover:border-orange-600/50 transition-colors">
                  <div className="relative">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-40 object-cover"
                    />
                    <button className="absolute inset-0 flex items-center justify-center bg-black/50 hover:bg-black/70 transition-colors">
                      <Play className="h-12 w-12 text-white" />
                    </button>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold mb-2">{video.title}</h3>
                    <div className="flex items-center justify-between text-sm text-gray-400">
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {video.duration}ث
                      </div>
                      <div className="flex items-center gap-1 text-orange-600">
                        <Zap className="h-4 w-4" />
                        {video.coinsUsed}
                      </div>
                    </div>
                    <div className="flex gap-2 mt-4">
                      <Button className="flex-1 bg-orange-600 hover:bg-orange-700 text-sm">
                        تحميل
                      </Button>
                      <Button variant="outline" className="flex-1 border-slate-700 text-sm">
                        مشاركة
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
