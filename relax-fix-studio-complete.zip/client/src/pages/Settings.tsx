import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Loader2, Music, Image, Type } from "lucide-react";
import { useState } from "react";

export default function Settings() {
  const { user } = useAuth();
  const { data: settings, isLoading } = trpc.settings.get.useQuery();
  const [formData, setFormData] = useState({
    primaryColor: "#0B1120",
    accentColor: "#F97316",
    animatedText: true,
    backgroundImage: "",
    backgroundMusic: "",
  });

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const handleSave = () => {
    // TODO: Implement settings update
    console.log("Save settings:", formData);
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold">الإعدادات</h1>
          <p className="text-slate-500 mt-2">تخصيص منصتك وإدارة الإعدادات</p>
        </div>

        {/* Colors Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Type className="h-5 w-5" />
              الألوان والتصميم
            </CardTitle>
            <CardDescription>اختر الألوان الأساسية للموقع</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">اللون الأساسي</label>
                <div className="flex gap-3">
                  <input
                    type="color"
                    value={formData.primaryColor}
                    onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                    className="h-12 w-20 rounded cursor-pointer"
                  />
                  <Input
                    type="text"
                    value={formData.primaryColor}
                    onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                    className="flex-1"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">لون الإبراز</label>
                <div className="flex gap-3">
                  <input
                    type="color"
                    value={formData.accentColor}
                    onChange={(e) => setFormData({ ...formData, accentColor: e.target.value })}
                    className="h-12 w-20 rounded cursor-pointer"
                  />
                  <Input
                    type="text"
                    value={formData.accentColor}
                    onChange={(e) => setFormData({ ...formData, accentColor: e.target.value })}
                    className="flex-1"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <input
                type="checkbox"
                id="animatedText"
                checked={formData.animatedText}
                onChange={(e) => setFormData({ ...formData, animatedText: e.target.checked })}
                className="h-4 w-4 rounded"
              />
              <label htmlFor="animatedText" className="text-sm font-medium cursor-pointer">
                تفعيل النصوص المتحركة
              </label>
            </div>

            <Button onClick={handleSave} className="bg-orange-600 hover:bg-orange-700">
              حفظ الألوان
            </Button>
          </CardContent>
        </Card>

        {/* Background Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Image className="h-5 w-5" />
              الخلفيات والصور
            </CardTitle>
            <CardDescription>أضف أو غيّر صورة الخلفية</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">صورة الخلفية</label>
              <div className="border-2 border-dashed rounded-lg p-6 text-center">
                <Input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  id="backgroundImage"
                  onChange={(e) => {
                    if (e.target.files?.[0]) {
                      setFormData({
                        ...formData,
                        backgroundImage: e.target.files[0].name,
                      });
                    }
                  }}
                />
                <label
                  htmlFor="backgroundImage"
                  className="cursor-pointer text-slate-600 hover:text-orange-600"
                >
                  {formData.backgroundImage || "اضغط لاختيار صورة أو اسحبها هنا"}
                </label>
              </div>
            </div>

            <Button onClick={handleSave} className="bg-orange-600 hover:bg-orange-700">
              حفظ الخلفية
            </Button>
          </CardContent>
        </Card>

        {/* Music Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Music className="h-5 w-5" />
              الموسيقى الخلفية
            </CardTitle>
            <CardDescription>أضف أو غيّر الموسيقى الخلفية</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">ملف الموسيقى</label>
              <div className="border-2 border-dashed rounded-lg p-6 text-center">
                <Input
                  type="file"
                  accept="audio/*"
                  className="hidden"
                  id="backgroundMusic"
                  onChange={(e) => {
                    if (e.target.files?.[0]) {
                      setFormData({
                        ...formData,
                        backgroundMusic: e.target.files[0].name,
                      });
                    }
                  }}
                />
                <label
                  htmlFor="backgroundMusic"
                  className="cursor-pointer text-slate-600 hover:text-orange-600"
                >
                  {formData.backgroundMusic || "اضغط لاختيار ملف موسيقى أو اسحبه هنا"}
                </label>
              </div>
            </div>

            {formData.backgroundMusic && (
              <div className="bg-slate-100 p-4 rounded-lg">
                <p className="text-sm text-slate-700">الملف المختار: {formData.backgroundMusic}</p>
                <audio
                  controls
                  className="w-full mt-2"
                  src={`/music/${formData.backgroundMusic}`}
                />
              </div>
            )}

            <Button onClick={handleSave} className="bg-orange-600 hover:bg-orange-700">
              حفظ الموسيقى
            </Button>
          </CardContent>
        </Card>

        {/* Account Section */}
        <Card>
          <CardHeader>
            <CardTitle>معلومات الحساب</CardTitle>
            <CardDescription>بيانات حسابك الشخصية</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">الاسم</label>
              <Input type="text" value={user.name || ""} disabled />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">البريد الإلكتروني</label>
              <Input type="email" value={user.email || ""} disabled />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">الخطة الحالية</label>
              <Input type="text" value={user.subscriptionPlan || "starter"} disabled />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">الرصيد المتاح</label>
              <Input type="text" value={`${user.credits || 0} نقطة`} disabled />
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
