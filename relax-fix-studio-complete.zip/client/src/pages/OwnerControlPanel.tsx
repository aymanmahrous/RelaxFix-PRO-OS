import { useState } from 'react';
import { Lock, Music, Image, Settings, LogOut } from 'lucide-react';
import { Button } from "@/components/ui/button";

/**
 * Owner Control Panel - Secure admin panel with password protection
 * Only the owner can access this panel to manage the platform
 */
export default function OwnerControlPanel() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  
  // Owner password - Change this to a strong password
  const OWNER_PASSWORD = 'RelaxFix@2026';

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === OWNER_PASSWORD) {
      setIsAuthenticated(true);
      setError('');
      setPassword('');
      // Store in session storage (not persistent)
      sessionStorage.setItem('ownerAuth', 'true');
    } else {
      setError('كلمة المرور غير صحيحة');
      setPassword('');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('ownerAuth');
  };

  // Check if already authenticated in session
  if (!isAuthenticated && sessionStorage.getItem('ownerAuth')) {
    setIsAuthenticated(true);
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white flex items-center justify-center p-4">
        <div className="max-w-md w-full">
          <div className="bg-slate-900 rounded-lg p-8 border border-orange-600">
            <div className="flex justify-center mb-6">
              <Lock className="h-12 w-12 text-orange-600" />
            </div>
            <h1 className="text-3xl font-bold text-center mb-2">لوحة التحكم</h1>
            <p className="text-gray-400 text-center mb-6">للمالك فقط</p>
            
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">كلمة المرور</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="أدخل كلمة المرور"
                  className="w-full px-4 py-2 rounded-lg bg-slate-800 border border-slate-700 focus:border-orange-600 focus:outline-none text-white"
                />
              </div>
              {error && <p className="text-red-500 text-sm">{error}</p>}
              <Button
                type="submit"
                className="w-full bg-orange-600 hover:bg-orange-700 text-lg py-2"
              >
                دخول
              </Button>
            </form>

            <p className="text-gray-500 text-xs text-center mt-4">
              هذه اللوحة محمية بكلمة مرور قوية
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8 pt-4">
          <h1 className="text-4xl font-bold">
            <span className="text-orange-600">لوحة</span> التحكم
          </h1>
          <Button
            onClick={handleLogout}
            className="bg-red-600 hover:bg-red-700 flex items-center gap-2"
          >
            <LogOut className="h-4 w-4" />
            تسجيل الخروج
          </Button>
        </div>

        {/* Control Sections */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Music Management */}
          <div className="bg-slate-900 rounded-lg p-6 border border-slate-800 hover:border-orange-600/50 transition-colors">
            <div className="flex items-center gap-3 mb-4">
              <Music className="h-6 w-6 text-orange-600" />
              <h2 className="text-xl font-bold">إدارة الموسيقى</h2>
            </div>
            <p className="text-gray-400 mb-4">تغيير الموسيقى الخلفية والقصائد</p>
            <div className="space-y-3">
              <button className="w-full bg-orange-600 hover:bg-orange-700 px-4 py-2 rounded-lg transition-colors">
                تحميل موسيقى جديدة
              </button>
              <button className="w-full bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-lg transition-colors">
                تغيير القصيدة
              </button>
              <button className="w-full bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-lg transition-colors">
                إضافة قرآن كريم
              </button>
            </div>
          </div>

          {/* Design Management */}
          <div className="bg-slate-900 rounded-lg p-6 border border-slate-800 hover:border-orange-600/50 transition-colors">
            <div className="flex items-center gap-3 mb-4">
              <Image className="h-6 w-6 text-orange-600" />
              <h2 className="text-xl font-bold">إدارة التصميم</h2>
            </div>
            <p className="text-gray-400 mb-4">تغيير الخلفيات والألوان والقالب</p>
            <div className="space-y-3">
              <button className="w-full bg-orange-600 hover:bg-orange-700 px-4 py-2 rounded-lg transition-colors">
                تغيير الخلفية
              </button>
              <button className="w-full bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-lg transition-colors">
                تغيير الألوان
              </button>
              <button className="w-full bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-lg transition-colors">
                تغيير القالب
              </button>
            </div>
          </div>

          {/* Settings Management */}
          <div className="bg-slate-900 rounded-lg p-6 border border-slate-800 hover:border-orange-600/50 transition-colors">
            <div className="flex items-center gap-3 mb-4">
              <Settings className="h-6 w-6 text-orange-600" />
              <h2 className="text-xl font-bold">الإعدادات</h2>
            </div>
            <p className="text-gray-400 mb-4">إدارة الأسعار والخطط والإعدادات</p>
            <div className="space-y-3">
              <button className="w-full bg-orange-600 hover:bg-orange-700 px-4 py-2 rounded-lg transition-colors">
                تعديل الأسعار
              </button>
              <button className="w-full bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-lg transition-colors">
                إدارة الخطط
              </button>
              <button className="w-full bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-lg transition-colors">
                إعدادات عامة
              </button>
            </div>
          </div>

          {/* Pricing Management */}
          <div className="bg-slate-900 rounded-lg p-6 border border-slate-800 hover:border-orange-600/50 transition-colors">
            <div className="flex items-center gap-3 mb-4">
              <h2 className="text-xl font-bold">💰 إدارة الأسعار</h2>
            </div>
            <p className="text-gray-400 mb-4">تعديل أسعار الخدمات والخطط</p>
            <div className="space-y-3">
              <div className="bg-slate-800 p-3 rounded-lg">
                <p className="text-sm text-gray-400">Starter: $29/شهر</p>
              </div>
              <div className="bg-slate-800 p-3 rounded-lg">
                <p className="text-sm text-gray-400">Pro: $79/شهر</p>
              </div>
              <div className="bg-slate-800 p-3 rounded-lg">
                <p className="text-sm text-gray-400">Enterprise: $199/شهر</p>
              </div>
              <button className="w-full bg-orange-600 hover:bg-orange-700 px-4 py-2 rounded-lg transition-colors mt-2">
                تعديل الأسعار
              </button>
            </div>
          </div>

          {/* Analytics */}
          <div className="bg-slate-900 rounded-lg p-6 border border-slate-800 hover:border-orange-600/50 transition-colors">
            <div className="flex items-center gap-3 mb-4">
              <h2 className="text-xl font-bold">📊 التحليلات</h2>
            </div>
            <p className="text-gray-400 mb-4">عرض إحصائيات الموقع والعملاء</p>
            <div className="space-y-3">
              <div className="bg-slate-800 p-3 rounded-lg">
                <p className="text-sm text-gray-400">الزيارات: 1,234</p>
              </div>
              <div className="bg-slate-800 p-3 rounded-lg">
                <p className="text-sm text-gray-400">المشتركون: 45</p>
              </div>
              <button className="w-full bg-orange-600 hover:bg-orange-700 px-4 py-2 rounded-lg transition-colors mt-2">
                عرض التفاصيل
              </button>
            </div>
          </div>

          {/* Notifications System */}
          <div className="bg-slate-900 rounded-lg p-6 border border-slate-800 hover:border-orange-600/50 transition-colors">
            <div className="flex items-center gap-3 mb-4">
              <h2 className="text-xl font-bold">🔔 نظام الإشعارات</h2>
            </div>
            <p className="text-gray-400 mb-4">إرسال إشعارات تليجرام وواتس</p>
            <div className="space-y-3">
              <div className="bg-slate-800 p-3 rounded-lg">
                <p className="text-sm text-gray-400">رقم الواتس: +971588259848</p>
              </div>
              <div className="bg-slate-800 p-3 rounded-lg">
                <p className="text-sm text-gray-400">قناة التليجرام: @relaxfixuae</p>
              </div>
              <button className="w-full bg-orange-600 hover:bg-orange-700 px-4 py-2 rounded-lg transition-colors">
                تكوين الإشعارات
              </button>
              <button className="w-full bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-lg transition-colors">
                اختبار الإشعارات
              </button>
            </div>
          </div>

          {/* Activity Log */}
          <div className="bg-slate-900 rounded-lg p-6 border border-slate-800 hover:border-orange-600/50 transition-colors">
            <div className="flex items-center gap-3 mb-4">
              <h2 className="text-xl font-bold">📋 سجل النشاط</h2>
            </div>
            <p className="text-gray-400 mb-4">عرض جميع التغييرات والتحديثات</p>
            <div className="space-y-2 text-sm text-gray-400">
              <p>• تم تحديث الأسعار - 2026-05-05</p>
              <p>• تم تغيير الخلفية - 2026-05-04</p>
              <p>• تم إضافة قصيدة جديدة - 2026-05-03</p>
              <button className="w-full bg-orange-600 hover:bg-orange-700 px-4 py-2 rounded-lg transition-colors mt-4">
                عرض السجل الكامل
              </button>
            </div>
          </div>
        </div>

        {/* Important Notice */}
        <div className="mt-8 bg-slate-900 rounded-lg p-6 border border-yellow-600/50">
          <h3 className="text-lg font-bold mb-2 text-yellow-600">⚠️ ملاحظة مهمة</h3>
          <p className="text-gray-400">
            هذه اللوحة محمية بكلمة مرور قوية. لا تشارك كلمة المرور مع أحد. جميع التغييرات التي تقوم بها سيتم تسجيلها في سجل النشاط.
          </p>
        </div>
      </div>
    </div>
  );
}
