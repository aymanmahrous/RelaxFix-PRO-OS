import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Plus, Edit2, Trash2, Loader2, Phone, Mail, MapPin } from "lucide-react";
import { useState } from "react";

export default function Customers() {
  const { user } = useAuth();
  const { data: customers, isLoading } = trpc.customers.list.useQuery();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    city: "",
    serviceNeeded: "",
  });

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement customer creation/update
    setShowForm(false);
    setFormData({ name: "", email: "", phone: "", city: "", serviceNeeded: "" });
  };

  const handleEdit = (customer: any) => {
    setFormData({
      name: customer.name,
      email: customer.email || "",
      phone: customer.phone || "",
      city: customer.city || "",
      serviceNeeded: customer.serviceNeeded || "",
    });
    setEditingId(customer.id);
    setShowForm(true);
  };

  const handleDelete = (id: number) => {
    // TODO: Implement customer deletion
    console.log("Delete customer:", id);
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-4xl font-bold">إدارة العملاء</h1>
            <p className="text-slate-500 mt-2">أضف أو عدّل بيانات العملاء</p>
          </div>
          <Button
            onClick={() => {
              setShowForm(true);
              setEditingId(null);
              setFormData({ name: "", email: "", phone: "", city: "", serviceNeeded: "" });
            }}
            className="bg-orange-600 hover:bg-orange-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            إضافة عميل جديد
          </Button>
        </div>

        {/* Form */}
        {showForm && (
          <Card>
            <CardHeader>
              <CardTitle>{editingId ? "تعديل بيانات العميل" : "إضافة عميل جديد"}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">الاسم</label>
                    <Input
                      type="text"
                      placeholder="اسم العميل"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">البريد الإلكتروني</label>
                    <Input
                      type="email"
                      placeholder="example@email.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">رقم الهاتف</label>
                    <Input
                      type="tel"
                      placeholder="+971 50 XXX XXXX"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">المدينة</label>
                    <Input
                      type="text"
                      placeholder="دبي، أبو ظبي، إلخ"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">الخدمة المطلوبة</label>
                  <Input
                    type="text"
                    placeholder="مثال: صيانة التكييف"
                    value={formData.serviceNeeded}
                    onChange={(e) => setFormData({ ...formData, serviceNeeded: e.target.value })}
                  />
                </div>

                <div className="flex gap-4 pt-4">
                  <Button type="submit" className="bg-orange-600 hover:bg-orange-700">
                    {editingId ? "تحديث" : "إضافة"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowForm(false);
                      setEditingId(null);
                      setFormData({ name: "", email: "", phone: "", city: "", serviceNeeded: "" });
                    }}
                  >
                    إلغاء
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Customers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            <div className="flex justify-center col-span-full py-8">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : customers && customers.length > 0 ? (
            customers.map((customer) => (
              <Card key={customer.id} className="hover:shadow-lg transition">
                <CardHeader>
                  <CardTitle>{customer.name}</CardTitle>
                  <CardDescription>{customer.serviceNeeded}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {customer.email && (
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Mail className="h-4 w-4" />
                      <a href={`mailto:${customer.email}`} className="hover:text-orange-600">
                        {customer.email}
                      </a>
                    </div>
                  )}
                  {customer.phone && (
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Phone className="h-4 w-4" />
                      <a href={`tel:${customer.phone}`} className="hover:text-orange-600">
                        {customer.phone}
                      </a>
                    </div>
                  )}
                  {customer.city && (
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <MapPin className="h-4 w-4" />
                      {customer.city}
                    </div>
                  )}

                  <div className="flex gap-2 pt-4">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(customer)}
                      className="flex-1"
                    >
                      <Edit2 className="h-4 w-4 mr-2" />
                      تعديل
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(customer.id)}
                      className="flex-1"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      حذف
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-slate-500 mb-4">لا توجد عملاء حتى الآن</p>
              <Button
                onClick={() => {
                  setShowForm(true);
                  setEditingId(null);
                }}
                className="bg-orange-600 hover:bg-orange-700"
              >
                إضافة عميل أول
              </Button>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
