import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Plus, Download, Share2, Undo2, Redo2, Type, Square, Circle, Image as ImageIcon, Palette } from 'lucide-react';

/**
 * Design Editor - Canva-like design tool
 */
export default function DesignEditor() {
  const [selectedTool, setSelectedTool] = useState<string | null>(null);
  const [designs, setDesigns] = useState<any[]>([]);
  const [currentDesign, setCurrentDesign] = useState<any>(null);
  const [showTemplates, setShowTemplates] = useState(true);

  const templates = [
    { id: 1, name: 'إعلان وسائل اجتماعية', size: '1080x1080px', category: 'social' },
    { id: 2, name: 'بطاقة عمل', size: '1000x600px', category: 'business' },
    { id: 3, name: 'غلاف فيديو', size: '1280x720px', category: 'video' },
    { id: 4, name: 'منشور مدونة', size: '1200x628px', category: 'blog' },
    { id: 5, name: 'إعلان بنر', size: '1920x1080px', category: 'banner' },
    { id: 6, name: 'قصة Instagram', size: '1080x1920px', category: 'story' },
  ];

  const tools = [
    { icon: Type, label: 'نص', id: 'text' },
    { icon: Square, label: 'مربع', id: 'rectangle' },
    { icon: Circle, label: 'دائرة', id: 'circle' },
    { icon: ImageIcon, label: 'صورة', id: 'image' },
    { icon: Palette, label: 'ألوان', id: 'colors' },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col">
      {/* Header */}
      <div className="bg-slate-900 border-b border-slate-800 p-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h1 className="text-2xl font-bold">محرر التصميم</h1>
          <span className="text-sm text-gray-400">Relax Fix Studio</span>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" className="border-slate-700">
            <Undo2 className="h-4 w-4 ml-2" />
            تراجع
          </Button>
          <Button variant="outline" className="border-slate-700">
            <Redo2 className="h-4 w-4 ml-2" />
            إعادة
          </Button>
          <Button className="bg-orange-600 hover:bg-orange-700 ml-4">
            <Download className="h-4 w-4 ml-2" />
            تحميل
          </Button>
          <Button variant="outline" className="border-slate-700">
            <Share2 className="h-4 w-4 ml-2" />
            مشاركة
          </Button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar - Templates & Tools */}
        <div className="w-64 bg-slate-900 border-r border-slate-800 overflow-y-auto">
          {showTemplates ? (
            <div className="p-4">
              <h2 className="text-lg font-bold mb-4">القوالب</h2>
              <div className="space-y-2">
                {templates.map(template => (
                  <button
                    key={template.id}
                    onClick={() => {
                      setCurrentDesign(template);
                      setShowTemplates(false);
                    }}
                    className="w-full text-right p-3 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors"
                  >
                    <div className="font-bold text-sm">{template.name}</div>
                    <div className="text-xs text-gray-400">{template.size}</div>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-4">
              <button
                onClick={() => setShowTemplates(true)}
                className="w-full mb-4 px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-sm"
              >
                ← العودة للقوالب
              </button>

              <h2 className="text-lg font-bold mb-4">الأدوات</h2>
              <div className="space-y-2">
                {tools.map(tool => {
                  const Icon = tool.icon;
                  return (
                    <button
                      key={tool.id}
                      onClick={() => setSelectedTool(tool.id)}
                      className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${
                        selectedTool === tool.id
                          ? 'bg-orange-600'
                          : 'bg-slate-800 hover:bg-slate-700'
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      <span>{tool.label}</span>
                    </button>
                  );
                })}
              </div>

              <h2 className="text-lg font-bold mt-6 mb-4">الطبقات</h2>
              <div className="space-y-2 bg-slate-800 rounded-lg p-3">
                <div className="text-sm text-gray-400">لا توجد طبقات حالياً</div>
              </div>
            </div>
          )}
        </div>

        {/* Canvas Area */}
        <div className="flex-1 flex items-center justify-center bg-slate-950 p-8">
          {currentDesign ? (
            <div className="bg-white rounded-lg shadow-2xl" style={{
              width: currentDesign.size === '1080x1080px' ? '400px' : '500px',
              height: currentDesign.size === '1080x1080px' ? '400px' : '300px',
              aspectRatio: currentDesign.size === '1080x1920px' ? '9/16' : '16/9'
            }}>
              <div className="w-full h-full bg-gradient-to-br from-slate-100 to-slate-200 rounded-lg flex items-center justify-center">
                <div className="text-center text-slate-600">
                  <h3 className="text-xl font-bold mb-2">{currentDesign.name}</h3>
                  <p className="text-sm">اسحب الأدوات هنا لبدء التصميم</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center">
              <Plus className="h-16 w-16 text-gray-600 mx-auto mb-4" />
              <h2 className="text-2xl font-bold mb-2">اختر قالباً للبدء</h2>
              <p className="text-gray-400">اختر من قوالبنا الجاهزة أو أنشئ تصميماً مخصصاً</p>
            </div>
          )}
        </div>

        {/* Right Sidebar - Properties */}
        <div className="w-64 bg-slate-900 border-l border-slate-800 overflow-y-auto p-4">
          <h2 className="text-lg font-bold mb-4">الخصائص</h2>

          {selectedTool ? (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-bold block mb-2">اللون</label>
                <div className="flex gap-2">
                  {['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8'].map(color => (
                    <button
                      key={color}
                      className="w-8 h-8 rounded-lg border-2 border-slate-700"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>

              <div>
                <label className="text-sm font-bold block mb-2">الحجم</label>
                <input
                  type="range"
                  min="10"
                  max="100"
                  className="w-full"
                />
              </div>

              <div>
                <label className="text-sm font-bold block mb-2">الشفافية</label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  className="w-full"
                />
              </div>
            </div>
          ) : (
            <div className="text-center text-gray-400">
              <p>اختر أداة لتعديل الخصائص</p>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="bg-slate-900 border-t border-slate-800 p-4 flex items-center justify-between">
        <div className="text-sm text-gray-400">
          {currentDesign && <span>التصميم الحالي: {currentDesign.name}</span>}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-400">العملات المتبقية: <span className="text-orange-600 font-bold">100</span></span>
        </div>
      </div>
    </div>
  );
}
