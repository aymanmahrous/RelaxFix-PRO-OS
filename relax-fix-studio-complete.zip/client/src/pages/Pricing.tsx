import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Check, Zap, Crown, Rocket } from 'lucide-react';
import { getLoginUrl } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";

/**
 * Pricing Page - Advanced subscription plans with flexible billing
 */
export default function Pricing() {
  const { isAuthenticated } = useAuth();
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  const plans = [
    {
      name: 'Starter',
      icon: Zap,
      monthlyPrice: 29,
      yearlyPrice: 290,
      description: 'للبدء والتجربة',
      features: [
        '10 تصاميم شهرياً',
        '5 فيديوهات شهرياً',
        'قوالب أساسية',
        'دعم البريد الإلكتروني',
        'تصدير بجودة عادية',
        'مساحة تخزين 5 GB'
      ],
      highlight: false
    },
    {
      name: 'Pro',
      icon: Crown,
      monthlyPrice: 79,
      yearlyPrice: 790,
      description: 'للمحترفين',
      features: [
        '100 تصميم شهرياً',
        '50 فيديو شهرياً',
        'جميع القوالب',
        'دعم الأولوية 24/7',
        'تصدير بجودة 4K',
        'مساحة تخزين 100 GB',
        'إزالة العلامات المائية',
        'أدوات متقدمة'
      ],
      highlight: true
    },
    {
      name: 'Enterprise',
      icon: Rocket,
      monthlyPrice: 199,
      yearlyPrice: 1990,
      description: 'للشركات الكبرى',
      features: [
        'تصاميم وفيديوهات غير محدودة',
        'جميع الميزات',
        'دعم مخصص 24/7',
        'تصدير بجودة 8K',
        'مساحة تخزين غير محدودة',
        'API Access',
        'تكامل مخصص',
        'فريق دعم مخصص',
        'تحديثات أولوية'
      ],
      highlight: false
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16 pt-8">
          <h1 className="text-5xl font-bold mb-4">
            خطط <span className="text-orange-600">مرنة</span> وبأسعار عادلة
          </h1>
          <p className="text-xl text-gray-400 mb-8">اختر الخطة التي تناسب احتياجاتك</p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-4 mb-12">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-6 py-2 rounded-lg font-bold transition-all ${
                billingCycle === 'monthly'
                  ? 'bg-orange-600 text-white'
                  : 'bg-slate-800 text-gray-400 hover:bg-slate-700'
              }`}
            >
              شهري
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`px-6 py-2 rounded-lg font-bold transition-all ${
                billingCycle === 'yearly'
                  ? 'bg-orange-600 text-white'
                  : 'bg-slate-800 text-gray-400 hover:bg-slate-700'
              }`}
            >
              سنوي
              <span className="ml-2 text-xs bg-green-600 px-2 py-1 rounded">توفير 20%</span>
            </button>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {plans.map((plan, idx) => {
            const Icon = plan.icon;
            const price = billingCycle === 'monthly' ? plan.monthlyPrice : plan.yearlyPrice;
            const period = billingCycle === 'monthly' ? 'شهرياً' : 'سنوياً';

            return (
              <div
                key={idx}
                className={`rounded-lg p-8 transition-all ${
                  plan.highlight
                    ? 'bg-gradient-to-b from-orange-600/20 to-orange-600/5 border-2 border-orange-600 scale-105'
                    : 'bg-slate-900 border border-slate-800 hover:border-orange-600/50'
                }`}
              >
                {plan.highlight && (
                  <div className="bg-orange-600 text-white px-4 py-1 rounded-full text-sm font-bold mb-4 inline-block">
                    الأفضل
                  </div>
                )}

                <div className="flex items-center gap-3 mb-4">
                  <Icon className="h-8 w-8 text-orange-600" />
                  <h2 className="text-2xl font-bold">{plan.name}</h2>
                </div>

                <p className="text-gray-400 mb-6">{plan.description}</p>

                <div className="mb-6">
                  <span className="text-4xl font-bold">${price}</span>
                  <span className="text-gray-400 ml-2">/{period}</span>
                </div>

                <Button
                  className={`w-full mb-8 ${
                    plan.highlight
                      ? 'bg-orange-600 hover:bg-orange-700'
                      : 'bg-slate-800 hover:bg-slate-700 border border-orange-600'
                  }`}
                  onClick={() => {
                    if (!isAuthenticated) {
                      window.location.href = getLoginUrl();
                    } else {
                      // Handle subscription
                      window.location.href = '/dashboard/subscribe?plan=' + plan.name.toLowerCase();
                    }
                  }}
                >
                  {isAuthenticated ? 'اشترك الآن' : 'ابدأ الآن'}
                </Button>

                <div className="space-y-3">
                  {plan.features.map((feature, fidx) => (
                    <div key={fidx} className="flex items-start gap-3">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-300">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* FAQ Section */}
        <div className="bg-slate-900 rounded-lg p-8 border border-slate-800 mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">الأسئلة الشائعة</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                q: 'هل يمكنني تغيير الخطة لاحقاً؟',
                a: 'نعم، يمكنك تغيير خطتك في أي وقت. سيتم حساب الفرق تلقائياً.'
              },
              {
                q: 'هل هناك فترة تجربة مجانية؟',
                a: 'نعم، احصل على 7 أيام تجربة مجانية بدون الحاجة لبطاقة ائتمان.'
              },
              {
                q: 'ماذا يحدث عند انتهاء الاشتراك؟',
                a: 'سيتم إرسال تذكير قبل انتهاء الاشتراك. يمكنك تجديده أو إلغاء الاشتراك.'
              },
              {
                q: 'هل هناك عقد طويل الأجل؟',
                a: 'لا، جميع الاشتراكات بدون التزام. يمكنك الإلغاء في أي وقت.'
              }
            ].map((faq, idx) => (
              <div key={idx} className="bg-slate-800/50 rounded-lg p-6">
                <h3 className="font-bold mb-2 text-orange-600">{faq.q}</h3>
                <p className="text-gray-400">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Money Back Guarantee */}
        <div className="bg-gradient-to-r from-orange-600/20 to-orange-600/5 rounded-lg p-8 border border-orange-600/50 text-center">
          <h3 className="text-2xl font-bold mb-4">ضمان استرجاع المال 100%</h3>
          <p className="text-gray-300 mb-4">
            إذا لم تكن راضياً عن الخدمة في أول 30 يوم، سنعيد لك كل أموالك بدون أسئلة.
          </p>
          <p className="text-sm text-gray-400">لا توجد شروط معقدة - فقط رضاك هو أولويتنا</p>
        </div>
      </div>
    </div>
  );
}
