import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Shield, Lock, Smartphone, Key, AlertCircle, CheckCircle, Copy } from 'lucide-react';

/**
 * Security Settings - 2FA, encryption, and backup management
 */
export default function SecuritySettings() {
  const [twoFAEnabled, setTwoFAEnabled] = useState(false);
  const [showQRCode, setShowQRCode] = useState(false);
  const [backupCodes, setBackupCodes] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'2fa' | 'backup' | 'encryption' | 'activity'>('2fa');

  const tabs = [
    { id: '2fa', label: 'المصادقة الثنائية', icon: Smartphone },
    { id: 'backup', label: 'النسخ الاحتياطية', icon: Lock },
    { id: 'encryption', label: 'التشفير', icon: Key },
    { id: 'activity', label: 'سجل النشاط', icon: AlertCircle }
  ];

  const handleEnable2FA = () => {
    setShowQRCode(true);
    setBackupCodes([
      'XXXX-XXXX-XXXX-XXXX-1',
      'XXXX-XXXX-XXXX-XXXX-2',
      'XXXX-XXXX-XXXX-XXXX-3',
      'XXXX-XXXX-XXXX-XXXX-4',
      'XXXX-XXXX-XXXX-XXXX-5',
      'XXXX-XXXX-XXXX-XXXX-6'
    ]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-12 pt-8">
          <h1 className="text-4xl font-bold mb-2">
            إعدادات <span className="text-orange-600">الأمان</span>
          </h1>
          <p className="text-gray-400">حماية حسابك بأعلى معايير الأمان</p>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 border-b border-slate-800">
          {tabs.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-orange-600 text-orange-600'
                    : 'border-transparent text-gray-400 hover:text-white'
                }`}
              >
                <Icon className="h-5 w-5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* 2FA Tab */}
        {activeTab === '2fa' && (
          <div className="space-y-6">
            <div className="bg-slate-900 rounded-lg p-8 border border-slate-800">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold mb-2">المصادقة الثنائية</h2>
                  <p className="text-gray-400">أضف طبقة أمان إضافية لحسابك</p>
                </div>
                <div className={`px-4 py-2 rounded-lg font-bold ${
                  twoFAEnabled
                    ? 'bg-green-600/20 text-green-400'
                    : 'bg-red-600/20 text-red-400'
                }`}>
                  {twoFAEnabled ? '✓ مفعّل' : '✗ معطّل'}
                </div>
              </div>

              {!twoFAEnabled ? (
                <div className="space-y-6">
                  <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-700">
                    <h3 className="font-bold mb-4 flex items-center gap-2">
                      <AlertCircle className="h-5 w-5 text-orange-600" />
                      لماذا تحتاج المصادقة الثنائية؟
                    </h3>
                    <ul className="space-y-2 text-sm text-gray-300">
                      <li>• حماية حسابك من الاختراق حتى لو تم اكتشاف كلمة المرور</li>
                      <li>• تحقق إضافي عند تسجيل الدخول من أجهزة جديدة</li>
                      <li>• إشعارات فورية بمحاولات الوصول المريبة</li>
                      <li>• حماية بيانات مشاريعك وعملاتك</li>
                    </ul>
                  </div>

                  <Button
                    onClick={handleEnable2FA}
                    className="w-full bg-orange-600 hover:bg-orange-700 py-3 text-lg"
                  >
                    <Smartphone className="h-5 w-5 ml-2" />
                    تفعيل المصادقة الثنائية
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="bg-green-600/10 rounded-lg p-4 border border-green-600/50 flex items-center gap-3">
                    <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0" />
                    <div>
                      <h4 className="font-bold">المصادقة الثنائية مفعّلة</h4>
                      <p className="text-sm text-gray-300">حسابك محمي بمصادقة ثنائية قوية</p>
                    </div>
                  </div>

                  <Button variant="outline" className="w-full border-red-600 text-red-600 hover:bg-red-600/10">
                    تعطيل المصادقة الثنائية
                  </Button>
                </div>
              )}
            </div>

            {showQRCode && !twoFAEnabled && (
              <div className="bg-slate-900 rounded-lg p-8 border border-slate-800">
                <h3 className="text-xl font-bold mb-6">خطوات التفعيل</h3>

                <div className="space-y-6">
                  {/* Step 1 */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-orange-600 flex items-center justify-center font-bold">1</div>
                    <div>
                      <h4 className="font-bold mb-2">حمّل تطبيق المصادقة</h4>
                      <p className="text-gray-400 mb-3">استخدم Google Authenticator أو Microsoft Authenticator أو Authy</p>
                      <div className="flex gap-2">
                        <Button variant="outline" className="border-slate-700 text-sm">
                          Google Authenticator
                        </Button>
                        <Button variant="outline" className="border-slate-700 text-sm">
                          Microsoft Authenticator
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-orange-600 flex items-center justify-center font-bold">2</div>
                    <div>
                      <h4 className="font-bold mb-2">امسح رمز QR</h4>
                      <div className="bg-white p-4 rounded-lg inline-block">
                        <div className="w-32 h-32 bg-slate-200 flex items-center justify-center text-slate-600">
                          QR Code
                        </div>
                      </div>
                      <p className="text-sm text-gray-400 mt-2">أو أدخل المفتاح يدوياً</p>
                      <div className="bg-slate-800 p-3 rounded-lg mt-2 font-mono text-sm break-all">
                        JBSWY3DPEBLW64TMMQ======
                      </div>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-orange-600 flex items-center justify-center font-bold">3</div>
                    <div>
                      <h4 className="font-bold mb-2">أدخل رمز التحقق</h4>
                      <input
                        type="text"
                        placeholder="000000"
                        className="w-32 px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-center text-2xl tracking-widest focus:outline-none focus:border-orange-600"
                      />
                    </div>
                  </div>

                  {/* Backup Codes */}
                  <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                    <h4 className="font-bold mb-3 flex items-center gap-2">
                      <AlertCircle className="h-5 w-5 text-orange-600" />
                      احفظ رموز النسخ الاحتياطية
                    </h4>
                    <p className="text-sm text-gray-400 mb-4">
                      احفظ هذه الرموز في مكان آمن. يمكنك استخدامها للوصول إلى حسابك إذا فقدت جهازك.
                    </p>
                    <div className="space-y-2 bg-slate-900 p-4 rounded-lg">
                      {backupCodes.map((code, idx) => (
                        <div key={idx} className="flex items-center justify-between">
                          <code className="font-mono text-sm">{code}</code>
                          <button className="text-gray-400 hover:text-white">
                            <Copy className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button className="w-full bg-orange-600 hover:bg-orange-700 py-3">
                    تأكيد التفعيل
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Backup Tab */}
        {activeTab === 'backup' && (
          <div className="space-y-6">
            <div className="bg-slate-900 rounded-lg p-8 border border-slate-800">
              <h2 className="text-2xl font-bold mb-6">النسخ الاحتياطية</h2>

              <div className="space-y-4">
                <div className="bg-green-600/10 rounded-lg p-4 border border-green-600/50 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-6 w-6 text-green-500" />
                    <div>
                      <h4 className="font-bold">نسخة احتياطية تلقائية</h4>
                      <p className="text-sm text-gray-300">آخر نسخة: اليوم الساعة 02:30 صباحاً</p>
                    </div>
                  </div>
                  <Button variant="outline" className="border-slate-700 text-sm">
                    تحميل
                  </Button>
                </div>

                <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                  <h4 className="font-bold mb-3">سجل النسخ الاحتياطية</h4>
                  <div className="space-y-2 text-sm">
                    {[
                      { date: '2026-05-05', time: '02:30', size: '125 MB' },
                      { date: '2026-05-04', time: '02:30', size: '120 MB' },
                      { date: '2026-05-03', time: '02:30', size: '118 MB' }
                    ].map((backup, idx) => (
                      <div key={idx} className="flex items-center justify-between p-2 bg-slate-900 rounded">
                        <span>{backup.date} - {backup.time}</span>
                        <span className="text-gray-400">{backup.size}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <Button className="w-full bg-orange-600 hover:bg-orange-700">
                  إنشاء نسخة احتياطية يدوية الآن
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Encryption Tab */}
        {activeTab === 'encryption' && (
          <div className="space-y-6">
            <div className="bg-slate-900 rounded-lg p-8 border border-slate-800">
              <h2 className="text-2xl font-bold mb-6">التشفير</h2>

              <div className="space-y-4">
                <div className="bg-green-600/10 rounded-lg p-4 border border-green-600/50">
                  <h4 className="font-bold mb-2 flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    تشفير SSL 256-bit
                  </h4>
                  <p className="text-sm text-gray-300">جميع البيانات مشفرة أثناء النقل</p>
                </div>

                <div className="bg-green-600/10 rounded-lg p-4 border border-green-600/50">
                  <h4 className="font-bold mb-2 flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    تشفير قاعدة البيانات
                  </h4>
                  <p className="text-sm text-gray-300">البيانات الحساسة مشفرة في قاعدة البيانات</p>
                </div>

                <div className="bg-green-600/10 rounded-lg p-4 border border-green-600/50">
                  <h4 className="font-bold mb-2 flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    تشفير النسخ الاحتياطية
                  </h4>
                  <p className="text-sm text-gray-300">النسخ الاحتياطية مشفرة بالكامل</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Activity Tab */}
        {activeTab === 'activity' && (
          <div className="space-y-6">
            <div className="bg-slate-900 rounded-lg p-8 border border-slate-800">
              <h2 className="text-2xl font-bold mb-6">سجل النشاط</h2>

              <div className="space-y-2">
                {[
                  { action: 'تسجيل دخول', device: 'Chrome - Windows', time: 'قبل ساعة', status: 'آمن' },
                  { action: 'تغيير كلمة المرور', device: 'Safari - iPhone', time: 'قبل يوم', status: 'آمن' },
                  { action: 'تسجيل دخول', device: 'Firefox - Linux', time: 'قبل يومين', status: 'آمن' }
                ].map((activity, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                    <div>
                      <h4 className="font-bold">{activity.action}</h4>
                      <p className="text-sm text-gray-400">{activity.device}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-400">{activity.time}</p>
                      <p className="text-sm text-green-500">{activity.status}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
