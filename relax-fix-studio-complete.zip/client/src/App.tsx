import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Services from "./pages/Services";
import Settings from "./pages/Settings";
import Invoices from "./pages/Invoices";
import Customers from "./pages/Customers";
import Orders from "./pages/Orders";
import AdminPanel from "./pages/AdminPanel";
import TrustSecurity from "./pages/TrustSecurity";
import Pricing from "./pages/Pricing";
import DesignEditor from "./pages/DesignEditor";
import VideoGenerator from "./pages/VideoGenerator";
import SecuritySettings from "./pages/SecuritySettings";
import AdvancedDashboard from "./pages/AdvancedDashboard";
import OwnerControlPanel from "./pages/OwnerControlPanel";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/services" component={Services} />
      <Route path="/settings" component={Settings} />
      <Route path="/invoices" component={Invoices} />
      <Route path="/customers" component={Customers} />
      <Route path="/orders" component={Orders} />
      <Route path="/admin" component={AdminPanel} />
      <Route path="/security" component={TrustSecurity} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/design" component={DesignEditor} />
      <Route path="/video" component={VideoGenerator} />
      <Route path="/security-settings" component={SecuritySettings} />
      <Route path="/advanced-dashboard" component={AdvancedDashboard} />
      <Route path="/owner-control" component={OwnerControlPanel} />
      <Route path="/404" component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
