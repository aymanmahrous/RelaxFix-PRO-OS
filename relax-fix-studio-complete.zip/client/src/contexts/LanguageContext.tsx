import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'ar' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const translations = {
  ar: {
    // Navigation
    'nav.dashboard': 'لوحة التحكم',
    'nav.services': 'الخدمات',
    'nav.customers': 'العملاء',
    'nav.orders': 'الطلبات',
    'nav.invoices': 'الفواتير',
    'nav.settings': 'الإعدادات',
    'nav.logout': 'تسجيل خروج',
    'nav.login': 'دخول',
    'nav.start': 'ابدأ الآن',

    // Home Page
    'home.title': 'منصة Relax Fix للإنتاج الإعلاني السينمائي',
    'home.subtitle': 'أنتج إعلانات احترافية بالذكاء الاصطناعي، أدر مشاريعك، وتابع عملائك من لوحة تحكم واحدة متكاملة',
    'home.cta.start': 'ابدأ مجاناً',
    'home.cta.learn': 'اعرف المزيد',
    'home.features': 'المميزات الرئيسية',
    'home.services': 'الخدمات المتاحة',
    'home.pricing': 'خطط الاشتراك',
    'home.stats.services': 'خدمات متخصصة',
    'home.stats.plans': 'خطط اشتراك',
    'home.stats.support': 'دعم عربي',

    // Dashboard
    'dashboard.title': 'لوحة التحكم',
    'dashboard.overview': 'نظرة عامة',
    'dashboard.projects': 'المشاريع',
    'dashboard.customers': 'العملاء',
    'dashboard.credits': 'الرصيد',
    'dashboard.invoices': 'الفواتير',

    // Services
    'services.title': 'إدارة الخدمات',
    'services.add': 'إضافة خدمة جديدة',
    'services.name': 'اسم الخدمة',
    'services.description': 'الوصف',
    'services.price': 'السعر',
    'services.category': 'الفئة',
    'services.status': 'الحالة',
    'services.edit': 'تعديل',
    'services.delete': 'حذف',
    'services.save': 'حفظ',
    'services.cancel': 'إلغاء',

    // Customers
    'customers.title': 'إدارة العملاء',
    'customers.add': 'إضافة عميل جديد',
    'customers.name': 'الاسم',
    'customers.email': 'البريد الإلكتروني',
    'customers.phone': 'الهاتف',
    'customers.city': 'المدينة',
    'customers.service': 'الخدمة المطلوبة',

    // Orders
    'orders.title': 'إدارة الطلبات',
    'orders.add': 'طلب جديد',
    'orders.id': 'رقم الطلب',
    'orders.service': 'الخدمة',
    'orders.amount': 'المبلغ',
    'orders.status': 'الحالة',
    'orders.date': 'التاريخ',

    // Invoices
    'invoices.title': 'الفواتير',
    'invoices.id': 'رقم الفاتورة',
    'invoices.amount': 'المبلغ',
    'invoices.status': 'الحالة',
    'invoices.paid': 'مدفوعة',
    'invoices.pending': 'معلقة',
    'invoices.failed': 'فشلت',

    // Settings
    'settings.title': 'الإعدادات',
    'settings.theme': 'المظهر',
    'settings.language': 'اللغة',
    'settings.colors': 'الألوان',
    'settings.background': 'الخلفية',
    'settings.music': 'الموسيقى',
    'settings.fontSize': 'حجم الخط',
    'settings.account': 'معلومات الحساب',
    'settings.notifications': 'الإشعارات',
    'settings.telegram': 'التليجرام',
    'settings.whatsapp': 'الواتس آب',

    // Common
    'common.save': 'حفظ',
    'common.cancel': 'إلغاء',
    'common.delete': 'حذف',
    'common.edit': 'تعديل',
    'common.view': 'عرض',
    'common.add': 'إضافة',
    'common.search': 'بحث',
    'common.loading': 'جاري التحميل...',
    'common.error': 'حدث خطأ',
    'common.success': 'تم بنجاح',
  },
  en: {
    // Navigation
    'nav.dashboard': 'Dashboard',
    'nav.services': 'Services',
    'nav.customers': 'Customers',
    'nav.orders': 'Orders',
    'nav.invoices': 'Invoices',
    'nav.settings': 'Settings',
    'nav.logout': 'Logout',
    'nav.login': 'Login',
    'nav.start': 'Start Now',

    // Home Page
    'home.title': 'Relax Fix Studio - Cinematic Advertising Platform',
    'home.subtitle': 'Create professional ads with AI, manage your projects, and track your clients from one integrated dashboard',
    'home.cta.start': 'Start Free',
    'home.cta.learn': 'Learn More',
    'home.features': 'Key Features',
    'home.services': 'Available Services',
    'home.pricing': 'Subscription Plans',
    'home.stats.services': 'Specialized Services',
    'home.stats.plans': 'Subscription Plans',
    'home.stats.support': 'Arabic Support',

    // Dashboard
    'dashboard.title': 'Dashboard',
    'dashboard.overview': 'Overview',
    'dashboard.projects': 'Projects',
    'dashboard.customers': 'Customers',
    'dashboard.credits': 'Credits',
    'dashboard.invoices': 'Invoices',

    // Services
    'services.title': 'Services Management',
    'services.add': 'Add New Service',
    'services.name': 'Service Name',
    'services.description': 'Description',
    'services.price': 'Price',
    'services.category': 'Category',
    'services.status': 'Status',
    'services.edit': 'Edit',
    'services.delete': 'Delete',
    'services.save': 'Save',
    'services.cancel': 'Cancel',

    // Customers
    'customers.title': 'Customers Management',
    'customers.add': 'Add New Customer',
    'customers.name': 'Name',
    'customers.email': 'Email',
    'customers.phone': 'Phone',
    'customers.city': 'City',
    'customers.service': 'Required Service',

    // Orders
    'orders.title': 'Orders Management',
    'orders.add': 'New Order',
    'orders.id': 'Order ID',
    'orders.service': 'Service',
    'orders.amount': 'Amount',
    'orders.status': 'Status',
    'orders.date': 'Date',

    // Invoices
    'invoices.title': 'Invoices',
    'invoices.id': 'Invoice ID',
    'invoices.amount': 'Amount',
    'invoices.status': 'Status',
    'invoices.paid': 'Paid',
    'invoices.pending': 'Pending',
    'invoices.failed': 'Failed',

    // Settings
    'settings.title': 'Settings',
    'settings.theme': 'Theme',
    'settings.language': 'Language',
    'settings.colors': 'Colors',
    'settings.background': 'Background',
    'settings.music': 'Music',
    'settings.fontSize': 'Font Size',
    'settings.account': 'Account Information',
    'settings.notifications': 'Notifications',
    'settings.telegram': 'Telegram',
    'settings.whatsapp': 'WhatsApp',

    // Common
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.delete': 'Delete',
    'common.edit': 'Edit',
    'common.view': 'View',
    'common.add': 'Add',
    'common.search': 'Search',
    'common.loading': 'Loading...',
    'common.error': 'Error',
    'common.success': 'Success',
  },
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('language') as Language | null;
    return saved || 'ar';
  });

  useEffect(() => {
    localStorage.setItem('language', language);
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['ar']] || key;
  };

  const isRTL = language === 'ar';

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
};
