import React, { createContext, useContext, useState, useEffect } from 'react';

export interface CustomizationSettings {
  fontSize: 'small' | 'medium' | 'large' | 'xlarge';
  fontSizeValue: number;
  primaryColor: string;
  secondaryColor: string;
  backgroundColor: string;
  textColor: string;
  backgroundImage?: string;
  backgroundMusic?: string;
  musicVolume: number;
  musicEnabled: boolean;
  animatedText: boolean;
  theme: 'dark' | 'light';
}

interface CustomizationContextType {
  settings: CustomizationSettings;
  updateSettings: (settings: Partial<CustomizationSettings>) => void;
  resetSettings: () => void;
  getFontSizeClass: () => string;
  applyCustomization: () => void;
}

const defaultSettings: CustomizationSettings = {
  fontSize: 'medium',
  fontSizeValue: 16,
  primaryColor: '#ff6600',
  secondaryColor: '#ffffff',
  backgroundColor: '#0f172a',
  textColor: '#ffffff',
  backgroundImage: undefined,
  backgroundMusic: undefined,
  musicVolume: 50,
  musicEnabled: false,
  animatedText: true,
  theme: 'dark',
};

const CustomizationContext = createContext<CustomizationContextType | undefined>(undefined);

export const CustomizationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<CustomizationSettings>(() => {
    const saved = localStorage.getItem('customizationSettings');
    return saved ? { ...defaultSettings, ...JSON.parse(saved) } : defaultSettings;
  });

  useEffect(() => {
    localStorage.setItem('customizationSettings', JSON.stringify(settings));
    applyCustomization();
  }, [settings]);

  const updateSettings = (newSettings: Partial<CustomizationSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const resetSettings = () => {
    setSettings(defaultSettings);
  };

  const getFontSizeClass = (): string => {
    switch (settings.fontSize) {
      case 'small':
        return 'text-sm';
      case 'medium':
        return 'text-base';
      case 'large':
        return 'text-lg';
      case 'xlarge':
        return 'text-xl';
      default:
        return 'text-base';
    }
  };

  const applyCustomization = () => {
    const root = document.documentElement;

    // Apply font size
    root.style.fontSize = `${settings.fontSizeValue}px`;

    // Apply colors
    root.style.setProperty('--primary-color', settings.primaryColor);
    root.style.setProperty('--secondary-color', settings.secondaryColor);
    root.style.setProperty('--bg-color', settings.backgroundColor);
    root.style.setProperty('--text-color', settings.textColor);

    // Apply background image
    if (settings.backgroundImage) {
      document.body.style.backgroundImage = `url(${settings.backgroundImage})`;
      document.body.style.backgroundSize = 'cover';
      document.body.style.backgroundAttachment = 'fixed';
    } else {
      document.body.style.backgroundColor = settings.backgroundColor;
      document.body.style.backgroundImage = 'none';
    }

    // Apply theme
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    // Apply animated text
    if (settings.animatedText) {
      document.documentElement.classList.add('animate-text');
    } else {
      document.documentElement.classList.remove('animate-text');
    }

    // Apply music
    if (settings.musicEnabled && settings.backgroundMusic) {
      const audioElement = document.getElementById('bg-music') as HTMLAudioElement;
      if (audioElement) {
        audioElement.src = settings.backgroundMusic;
        audioElement.volume = settings.musicVolume / 100;
        audioElement.play().catch((e) => console.log('Auto-play prevented:', e));
      }
    }
  };

  return (
    <CustomizationContext.Provider
      value={{
        settings,
        updateSettings,
        resetSettings,
        getFontSizeClass,
        applyCustomization,
      }}
    >
      {/* Hidden audio element for background music */}
      <audio id="bg-music" loop style={{ display: 'none' }} />
      {children}
    </CustomizationContext.Provider>
  );
};

export const useCustomization = () => {
  const context = useContext(CustomizationContext);
  if (!context) {
    throw new Error('useCustomization must be used within CustomizationProvider');
  }
  return context;
};
