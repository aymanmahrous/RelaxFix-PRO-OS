/**
 * Telegram Bot Integration Service
 * Sends notifications to Telegram bot
 */

const TELEGRAM_BOT_TOKEN = '8229748660:AAE3miKJBc60REBoJxzBc2c1jEhuuiRw0C0';
const TELEGRAM_BOT_ID = '7895113378';
const TELEGRAM_API_URL = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}`;

interface TelegramMessage {
  chatId: string | number;
  text: string;
  parseMode?: 'HTML' | 'Markdown' | 'MarkdownV2';
  replyMarkup?: any;
}

interface TelegramNotification {
  type: 'order' | 'invoice' | 'customer' | 'project' | 'alert';
  title: string;
  message: string;
  data?: any;
  userId?: number;
  phoneNumber?: string;
}

/**
 * Send message to Telegram
 */
export async function sendTelegramMessage(params: TelegramMessage): Promise<boolean> {
  try {
    const response = await fetch(`${TELEGRAM_API_URL}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: params.chatId,
        text: params.text,
        parse_mode: params.parseMode || 'HTML',
        reply_markup: params.replyMarkup,
      }),
    });

    if (!response.ok) {
      console.error('[Telegram] Failed to send message:', await response.text());
      return false;
    }

    console.log('[Telegram] Message sent successfully');
    return true;
  } catch (error) {
    console.error('[Telegram] Error sending message:', error);
    return false;
  }
}

/**
 * Send notification via Telegram
 */
export async function sendTelegramNotification(notification: TelegramNotification): Promise<boolean> {
  try {
    let messageText = '';

    switch (notification.type) {
      case 'order':
        messageText = `
📦 <b>طلب جديد</b>

<b>العنوان:</b> ${notification.title}
<b>الرسالة:</b> ${notification.message}
${notification.data?.orderId ? `<b>رقم الطلب:</b> ${notification.data.orderId}` : ''}
${notification.data?.amount ? `<b>المبلغ:</b> ${notification.data.amount} AED` : ''}
${notification.data?.service ? `<b>الخدمة:</b> ${notification.data.service}` : ''}
        `;
        break;

      case 'invoice':
        messageText = `
💰 <b>فاتورة جديدة</b>

<b>العنوان:</b> ${notification.title}
<b>الرسالة:</b> ${notification.message}
${notification.data?.invoiceId ? `<b>رقم الفاتورة:</b> ${notification.data.invoiceId}` : ''}
${notification.data?.amount ? `<b>المبلغ:</b> ${notification.data.amount} AED` : ''}
${notification.data?.dueDate ? `<b>تاريخ الاستحقاق:</b> ${notification.data.dueDate}` : ''}
        `;
        break;

      case 'customer':
        messageText = `
👤 <b>عميل جديد</b>

<b>العنوان:</b> ${notification.title}
<b>الرسالة:</b> ${notification.message}
${notification.data?.customerName ? `<b>الاسم:</b> ${notification.data.customerName}` : ''}
${notification.data?.phone ? `<b>الهاتف:</b> ${notification.data.phone}` : ''}
${notification.data?.service ? `<b>الخدمة المطلوبة:</b> ${notification.data.service}` : ''}
        `;
        break;

      case 'project':
        messageText = `
🎬 <b>مشروع جديد</b>

<b>العنوان:</b> ${notification.title}
<b>الرسالة:</b> ${notification.message}
${notification.data?.projectName ? `<b>اسم المشروع:</b> ${notification.data.projectName}` : ''}
${notification.data?.status ? `<b>الحالة:</b> ${notification.data.status}` : ''}
        `;
        break;

      case 'alert':
        messageText = `
⚠️ <b>تنبيه مهم</b>

<b>العنوان:</b> ${notification.title}
<b>الرسالة:</b> ${notification.message}
        `;
        break;

      default:
        messageText = `${notification.title}\n\n${notification.message}`;
    }

    // Send to bot admin (your user ID)
    const success = await sendTelegramMessage({
      chatId: TELEGRAM_BOT_ID,
      text: messageText,
      parseMode: 'HTML',
    });

    return success;
  } catch (error) {
    console.error('[Telegram] Error sending notification:', error);
    return false;
  }
}

/**
 * Send notification to specific user
 */
export async function sendTelegramToUser(
  userId: string | number,
  notification: TelegramNotification
): Promise<boolean> {
  try {
    let messageText = `${notification.title}\n\n${notification.message}`;

    const success = await sendTelegramMessage({
      chatId: userId,
      text: messageText,
      parseMode: 'HTML',
    });

    return success;
  } catch (error) {
    console.error('[Telegram] Error sending message to user:', error);
    return false;
  }
}

/**
 * Get bot info
 */
export async function getTelegramBotInfo(): Promise<any> {
  try {
    const response = await fetch(`${TELEGRAM_API_URL}/getMe`);
    if (!response.ok) {
      throw new Error('Failed to get bot info');
    }
    return await response.json();
  } catch (error) {
    console.error('[Telegram] Error getting bot info:', error);
    return null;
  }
}

/**
 * Send inline keyboard message
 */
export async function sendTelegramWithButtons(
  chatId: string | number,
  text: string,
  buttons: Array<Array<{ text: string; url?: string; callback_data?: string }>>
): Promise<boolean> {
  try {
    const inlineKeyboard = buttons.map((row) =>
      row.map((btn) => ({
        text: btn.text,
        url: btn.url,
        callback_data: btn.callback_data,
      }))
    );

    return await sendTelegramMessage({
      chatId,
      text,
      parseMode: 'HTML',
      replyMarkup: {
        inline_keyboard: inlineKeyboard,
      },
    });
  } catch (error) {
    console.error('[Telegram] Error sending message with buttons:', error);
    return false;
  }
}
