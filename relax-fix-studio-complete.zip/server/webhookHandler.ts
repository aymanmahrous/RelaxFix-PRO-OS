/**
 * Stripe Webhook Handler
 * Processes webhook events from Stripe
 */

import { Router, Request, Response } from 'express';
import { handleWebhookEvent } from './stripeService';
import { sendTelegramNotification } from './telegramService';
import { sendWhatsAppNotification } from './whatsappService';

const webhookRouter = Router();

interface WebhookRequest extends Request {
  rawBody?: string;
}

/**
 * Stripe Webhook Endpoint
 */
webhookRouter.post('/stripe', async (req: WebhookRequest, res: Response) => {
  try {
    const signature = req.headers['stripe-signature'] as string;
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || '';

    if (!signature || !webhookSecret) {
      console.error('[Webhook] Missing signature or secret');
      return res.status(400).json({ error: 'Missing signature' });
    }

    const body = req.rawBody || JSON.stringify(req.body);

    // Verify and handle webhook
    const result = await handleWebhookEvent(body, signature, webhookSecret);

    if (result.success) {
      // Send notifications based on event type
      switch (result.type) {
        case 'payment_succeeded':
          await sendTelegramNotification({
            type: 'invoice',
            title: 'تم استقبال الدفع',
            message: 'تم استقبال دفعتك بنجاح',
            data: { paymentId: result.paymentId },
          });
          break;

        case 'payment_failed':
          await sendTelegramNotification({
            type: 'alert',
            title: 'فشل الدفع',
            message: 'حدث خطأ في معالجة دفعتك',
            data: { paymentId: result.paymentId },
          });
          break;

        case 'subscription_created':
          await sendTelegramNotification({
            type: 'alert',
            title: 'اشتراك جديد',
            message: 'تم تفعيل اشتراكك بنجاح',
            data: { subscriptionId: result.subscriptionId },
          });
          break;

        case 'subscription_deleted':
          await sendTelegramNotification({
            type: 'alert',
            title: 'إلغاء الاشتراك',
            message: 'تم إلغاء اشتراكك',
            data: { subscriptionId: result.subscriptionId },
          });
          break;

        case 'invoice_paid':
          await sendTelegramNotification({
            type: 'invoice',
            title: 'دفعت الفاتورة',
            message: 'تم دفع الفاتورة بنجاح',
            data: { invoiceId: result.invoiceId },
          });
          break;

        case 'invoice_payment_failed':
          await sendTelegramNotification({
            type: 'alert',
            title: 'فشل دفع الفاتورة',
            message: 'فشل دفع الفاتورة',
            data: { invoiceId: result.invoiceId },
          });
          break;
      }

      return res.json({ received: true });
    } else {
      console.error('[Webhook] Event handling failed:', result.error);
      return res.status(400).json({ error: result.error });
    }
  } catch (error) {
    console.error('[Webhook] Error processing webhook:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Telegram Webhook Endpoint
 */
webhookRouter.post('/telegram', async (req: Request, res: Response) => {
  try {
    const { message } = req.body;

    if (message && message.text) {
      const text = message.text.toLowerCase();

      // Handle commands
      if (text === '/start') {
        console.log('[Telegram] User started bot:', message.from.id);
        // Send welcome message
      } else if (text === '/help') {
        console.log('[Telegram] User requested help:', message.from.id);
        // Send help message
      } else if (text === '/status') {
        console.log('[Telegram] User requested status:', message.from.id);
        // Send status message
      }
    }

    return res.json({ ok: true });
  } catch (error) {
    console.error('[Telegram] Error processing webhook:', error);
    return res.status(500).json({ ok: false });
  }
});

/**
 * Health Check Endpoint
 */
webhookRouter.get('/health', (req: Request, res: Response) => {
  return res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    services: {
      stripe: 'connected',
      telegram: 'connected',
      whatsapp: 'connected',
    },
  });
});

export default webhookRouter;
