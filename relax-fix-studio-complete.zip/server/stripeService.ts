/**
 * Stripe Payment Integration Service
 * Handles all payment processing, subscriptions, and invoicing
 */

import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2024-04-10' as any,
});

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  currency: string;
  interval: 'month' | 'year';
  features: string[];
}

export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: string;
  clientSecret: string;
}

export interface StripeCustomer {
  id: string;
  email: string;
  name?: string;
  subscriptionId?: string;
  subscriptionStatus?: string;
}

/**
 * Create a Stripe customer
 */
export async function createStripeCustomer(
  email: string,
  name?: string
): Promise<StripeCustomer | null> {
  try {
    const customer = await stripe.customers.create({
      email,
      name,
      metadata: {
        createdAt: new Date().toISOString(),
      },
    });

    return {
      id: customer.id,
      email: customer.email || '',
      name: customer.name || undefined,
    };
  } catch (error) {
    console.error('[Stripe] Error creating customer:', error);
    return null;
  }
}

/**
 * Create a payment intent
 */
export async function createPaymentIntent(
  amount: number,
  currency: string = 'aed',
  customerId?: string,
  description?: string
): Promise<PaymentIntent | null> {
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // Convert to cents
      currency,
      customer: customerId,
      description,
      metadata: {
        createdAt: new Date().toISOString(),
      },
    });

    return {
      id: paymentIntent.id,
      amount: paymentIntent.amount / 100,
      currency: paymentIntent.currency,
      status: paymentIntent.status,
      clientSecret: paymentIntent.client_secret || '',
    };
  } catch (error) {
    console.error('[Stripe] Error creating payment intent:', error);
    return null;
  }
}

/**
 * Create a subscription
 */
export async function createSubscription(
  customerId: string,
  priceId: string,
  trialDays?: number
): Promise<any> {
  try {
    const subscription = await stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: priceId }],
      trial_period_days: trialDays,
      metadata: {
        createdAt: new Date().toISOString(),
      },
    });

    return {
      id: subscription.id,
      status: subscription.status,
      currentPeriodStart: new Date((subscription as any).current_period_start * 1000),
      currentPeriodEnd: new Date((subscription as any).current_period_end * 1000),
    };
  } catch (error) {
    console.error('[Stripe] Error creating subscription:', error);
    return null;
  }
}

/**
 * Cancel a subscription
 */
export async function cancelSubscription(subscriptionId: string): Promise<boolean> {
  try {
    await (stripe.subscriptions as any).del(subscriptionId);
    return true;
  } catch (error) {
    console.error('[Stripe] Error canceling subscription:', error);
    return false;
  }
}

/**
 * Get subscription details
 */
export async function getSubscription(subscriptionId: string): Promise<any> {
  try {
    const subscription = await stripe.subscriptions.retrieve(subscriptionId);

    return {
      id: subscription.id,
      status: subscription.status,
      currentPeriodStart: new Date((subscription as any).current_period_start * 1000),
      currentPeriodEnd: new Date((subscription as any).current_period_end * 1000),
      items: subscription.items.data.map((item) => ({
        priceId: (item.price as any).id,
        amount: ((item.price as any).unit_amount || 0) / 100,
      })),
    };
  } catch (error) {
    console.error('[Stripe] Error getting subscription:', error);
    return null;
  }
}

/**
 * Create an invoice
 */
export async function createInvoice(
  customerId: string,
  items: Array<{ description: string; amount: number; quantity: number }>,
  dueDate?: Date
): Promise<any> {
  try {
    const invoice = await stripe.invoices.create({
      customer: customerId,
      due_date: dueDate ? Math.floor(dueDate.getTime() / 1000) : undefined,
      metadata: {
        createdAt: new Date().toISOString(),
      },
    });

    // Add line items
    for (const item of items) {
      await stripe.invoiceItems.create({
        invoice: invoice.id,
        customer: customerId,
        description: item.description,
        amount: Math.round(item.amount * 100),
        quantity: item.quantity,
      });
    }

    // Finalize the invoice
    const finalizedInvoice = await stripe.invoices.finalizeInvoice(invoice.id);

    return {
      id: finalizedInvoice.id,
      status: finalizedInvoice.status,
      amount: (finalizedInvoice.amount_due || 0) / 100,
      pdfUrl: (finalizedInvoice as any).pdf,
      hostedInvoiceUrl: finalizedInvoice.hosted_invoice_url,
    };
  } catch (error) {
    console.error('[Stripe] Error creating invoice:', error);
    return null;
  }
}

/**
 * Get invoice details
 */
export async function getInvoice(invoiceId: string): Promise<any> {
  try {
    const invoice = await stripe.invoices.retrieve(invoiceId);

    return {
      id: invoice.id,
      status: invoice.status,
      amount: (invoice.amount_due || 0) / 100,
      paidAmount: (invoice.amount_paid || 0) / 100,
      pdf: (invoice as any).pdf,
      hostedInvoiceUrl: invoice.hosted_invoice_url,
      dueDate: invoice.due_date ? new Date(invoice.due_date * 1000) : null,
    };
  } catch (error) {
    console.error('[Stripe] Error getting invoice:', error);
    return null;
  }
}

/**
 * List invoices for a customer
 */
export async function listInvoices(customerId: string, limit: number = 10): Promise<any[]> {
  try {
    const invoices = await stripe.invoices.list({
      customer: customerId,
      limit,
    });

    return invoices.data.map((invoice) => ({
      id: invoice.id,
      status: invoice.status,
      amount: (invoice.amount_due || 0) / 100,
      paidAmount: (invoice.amount_paid || 0) / 100,
      createdAt: new Date(invoice.created * 1000),
      dueDate: invoice.due_date ? new Date(invoice.due_date * 1000) : null,
    }));
  } catch (error) {
    console.error('[Stripe] Error listing invoices:', error);
    return [];
  }
}

/**
 * Verify webhook signature
 */
export function verifyWebhookSignature(
  body: string,
  signature: string,
  webhookSecret: string
): boolean {
  try {
    const event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
    return true;
  } catch (error) {
    console.error('[Stripe] Webhook signature verification failed:', error);
    return false;
  }
}

/**
 * Handle webhook events
 */
export async function handleWebhookEvent(
  body: string,
  signature: string,
  webhookSecret: string
): Promise<any> {
  try {
    const event = stripe.webhooks.constructEvent(body, signature, webhookSecret);

    switch (event.type) {
      case 'payment_intent.succeeded':
        console.log('[Stripe] Payment succeeded:', event.data.object.id);
        return { success: true, type: 'payment_succeeded' };

      case 'payment_intent.payment_failed':
        console.log('[Stripe] Payment failed:', event.data.object.id);
        return { success: false, type: 'payment_failed' };

      case 'customer.subscription.created':
        console.log('[Stripe] Subscription created:', event.data.object.id);
        return { success: true, type: 'subscription_created' };

      case 'customer.subscription.deleted':
        console.log('[Stripe] Subscription deleted:', event.data.object.id);
        return { success: true, type: 'subscription_deleted' };

      case 'invoice.payment_succeeded':
        console.log('[Stripe] Invoice paid:', event.data.object.id);
        return { success: true, type: 'invoice_paid' };

      case 'invoice.payment_failed':
        console.log('[Stripe] Invoice payment failed:', event.data.object.id);
        return { success: false, type: 'invoice_payment_failed' };

      default:
        console.log('[Stripe] Unhandled event type:', event.type);
        return { success: true, type: 'unhandled' };
    }
  } catch (error) {
    console.error('[Stripe] Error handling webhook:', error);
    return { success: false, error: 'Webhook processing failed' };
  }
}

/**
 * Get payment method details
 */
export async function getPaymentMethod(paymentMethodId: string): Promise<any> {
  try {
    const paymentMethod = await stripe.paymentMethods.retrieve(paymentMethodId);

    return {
      id: paymentMethod.id,
      type: paymentMethod.type,
      card: paymentMethod.card,
      billing_details: paymentMethod.billing_details,
    };
  } catch (error) {
    console.error('[Stripe] Error getting payment method:', error);
    return null;
  }
}

/**
 * Refund a payment
 */
export async function refundPayment(paymentIntentId: string, amount?: number): Promise<boolean> {
  try {
    await stripe.refunds.create({
      payment_intent: paymentIntentId,
      amount: amount ? Math.round(amount * 100) : undefined,
    });

    return true;
  } catch (error) {
    console.error('[Stripe] Error refunding payment:', error);
    return false;
  }
}

/**
 * Get customer details
 */
export async function getCustomer(customerId: string): Promise<StripeCustomer | null> {
  try {
    const customer = await stripe.customers.retrieve(customerId);

    if (customer.deleted) {
      return null;
    }

    return {
      id: customer.id,
      email: customer.email || '',
      name: customer.name || undefined,
    };
  } catch (error) {
    console.error('[Stripe] Error getting customer:', error);
    return null;
  }
}
