/**
 * WhatsApp Integration Service
 * Sends notifications via WhatsApp
 * Using Twilio or similar service
 */

// WhatsApp Configuration
const WHATSAPP_PHONE_NUMBER = '+971588259848'; // Your WhatsApp number
const WHATSAPP_API_URL = 'https://api.whatsapp.com/send'; // WhatsApp Business API

interface WhatsAppMessage {
  to: string; // Phone number with country code (e.g., +971XXXXXXXXX)
  message: string;
  mediaUrl?: string;
}

interface WhatsAppNotification {
  type: 'order' | 'invoice' | 'customer' | 'project' | 'alert';
  title: string;
  message: string;
  data?: any;
  recipientPhone: string;
}

/**
 * Send WhatsApp message
 */
export async function sendWhatsAppMessage(params: WhatsAppMessage): Promise<boolean> {
  try {
    // For direct WhatsApp link (without API)
    const encodedMessage = encodeURIComponent(params.message);
    const whatsappLink = `https://wa.me/${params.to.replace('+', '')}?text=${encodedMessage}`;

    console.log('[WhatsApp] Message link:', whatsappLink);

    // If using Twilio or similar service, uncomment below:
    /*
    const response = await fetch('https://api.twilio.com/2010-04-01/Accounts/YOUR_ACCOUNT_SID/Messages.json', {
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + Buffer.from('YOUR_ACCOUNT_SID:YOUR_AUTH_TOKEN').toString('base64'),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        From: 'whatsapp:+YOUR_TWILIO_NUMBER',
        To: `whatsapp:${params.to}`,
        Body: params.message,
      }).toString(),
    });

    if (!response.ok) {
      console.error('[WhatsApp] Failed to send message:', await response.text());
      return false;
    }
    */

    return true;
  } catch (error) {
    console.error('[WhatsApp] Error sending message:', error);
    return false;
  }
}

/**
 * Send WhatsApp notification
 */
export async function sendWhatsAppNotification(
  notification: WhatsAppNotification
): Promise<boolean> {
  try {
    let messageText = '';

    switch (notification.type) {
      case 'order':
        messageText = `
📦 *طلب جديد*

*العنوان:* ${notification.title}
*الرسالة:* ${notification.message}
${notification.data?.orderId ? `*رقم الطلب:* ${notification.data.orderId}` : ''}
${notification.data?.amount ? `*المبلغ:* ${notification.data.amount} AED` : ''}
${notification.data?.service ? `*الخدمة:* ${notification.data.service}` : ''}
        `;
        break;

      case 'invoice':
        messageText = `
💰 *فاتورة جديدة*

*العنوان:* ${notification.title}
*الرسالة:* ${notification.message}
${notification.data?.invoiceId ? `*رقم الفاتورة:* ${notification.data.invoiceId}` : ''}
${notification.data?.amount ? `*المبلغ:* ${notification.data.amount} AED` : ''}
${notification.data?.dueDate ? `*تاريخ الاستحقاق:* ${notification.data.dueDate}` : ''}
        `;
        break;

      case 'customer':
        messageText = `
👤 *عميل جديد*

*العنوان:* ${notification.title}
*الرسالة:* ${notification.message}
${notification.data?.customerName ? `*الاسم:* ${notification.data.customerName}` : ''}
${notification.data?.phone ? `*الهاتف:* ${notification.data.phone}` : ''}
${notification.data?.service ? `*الخدمة المطلوبة:* ${notification.data.service}` : ''}
        `;
        break;

      case 'project':
        messageText = `
🎬 *مشروع جديد*

*العنوان:* ${notification.title}
*الرسالة:* ${notification.message}
${notification.data?.projectName ? `*اسم المشروع:* ${notification.data.projectName}` : ''}
${notification.data?.status ? `*الحالة:* ${notification.data.status}` : ''}
        `;
        break;

      case 'alert':
        messageText = `
⚠️ *تنبيه مهم*

*العنوان:* ${notification.title}
*الرسالة:* ${notification.message}
        `;
        break;

      default:
        messageText = `${notification.title}\n\n${notification.message}`;
    }

    const success = await sendWhatsAppMessage({
      to: notification.recipientPhone,
      message: messageText,
    });

    return success;
  } catch (error) {
    console.error('[WhatsApp] Error sending notification:', error);
    return false;
  }
}

/**
 * Send WhatsApp message to admin
 */
export async function sendWhatsAppToAdmin(notification: WhatsAppNotification): Promise<boolean> {
  try {
    return await sendWhatsAppNotification({
      ...notification,
      recipientPhone: WHATSAPP_PHONE_NUMBER,
    });
  } catch (error) {
    console.error('[WhatsApp] Error sending message to admin:', error);
    return false;
  }
}

/**
 * Generate WhatsApp link for manual sending
 */
export function generateWhatsAppLink(phoneNumber: string, message: string): string {
  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/${phoneNumber.replace('+', '')}?text=${encodedMessage}`;
}

/**
 * Send WhatsApp message with media
 */
export async function sendWhatsAppWithMedia(
  phoneNumber: string,
  message: string,
  mediaUrl: string
): Promise<boolean> {
  try {
    // This would require Twilio or similar API
    // For now, just return the link
    const link = generateWhatsAppLink(phoneNumber, message);
    console.log('[WhatsApp] Media message link:', link);
    return true;
  } catch (error) {
    console.error('[WhatsApp] Error sending media message:', error);
    return false;
  }
}
