import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, services, projects, invoices, notifications, settings, customers, orders, subscriptionPlans, userCoins, coinTransactions, referrals, loyaltyPoints, loyaltyTransactions, audioContent, adminSettings, designTemplates, userDesigns, videoJobs, backupHistory, subscriptionHistory, twoFactorAuth } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Services queries
export async function getAllServices() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(services).where(eq(services.isActive, true));
}

export async function getServiceById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(services).where(eq(services.id, id)).limit(1);
  return result[0];
}

// Projects queries
export async function getUserProjects(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(projects).where(eq(projects.userId, userId));
}

// Invoices queries
export async function getUserInvoices(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(invoices).where(eq(invoices.userId, userId)).orderBy(desc(invoices.createdAt));
}

// Notifications queries
export async function getUserNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt));
}

// Settings queries
export async function getUserSettings(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(settings).where(eq(settings.userId, userId)).limit(1);
  return result[0];
}

// Customers queries
export async function getUserCustomers(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(customers).where(eq(customers.userId, userId));
}

// Orders queries
export async function getUserOrders(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
}

// Subscription Plans queries
export async function getAllSubscriptionPlans() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(subscriptionPlans);
}

// User Coins queries
export async function getUserCoins(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(userCoins).where(eq(userCoins.userId, userId)).limit(1);
  return result[0];
}

export async function createUserCoins(userId: number, initialCoins: number = 0) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(userCoins).values({
    userId,
    totalCoins: initialCoins.toString(),
    earnedCoins: initialCoins.toString(),
    spentCoins: "0",
  });
}

export async function updateUserCoins(userId: number, totalCoins: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.update(userCoins).set({ totalCoins: totalCoins.toString() }).where(eq(userCoins.userId, userId));
}

// Coin Transactions queries
export async function getUserCoinTransactions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(coinTransactions).where(eq(coinTransactions.userId, userId)).orderBy(desc(coinTransactions.createdAt));
}

export async function addCoinTransaction(userId: number, amount: number, type: string, description?: string, relatedOrderId?: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(coinTransactions).values({
    userId,
    amount: amount.toString(),
    type: type as any,
    description,
    relatedOrderId,
  });
}

// Referral queries
export async function getUserReferrals(referrerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(referrals).where(eq(referrals.referrerId, referrerId));
}

export async function getReferralByCode(code: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(referrals).where(eq(referrals.referralCode, code)).limit(1);
  return result[0];
}

export async function createReferral(referrerId: number, code: string, link: string) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(referrals).values({
    referrerId,
    referralCode: code,
    referralLink: link,
  });
}

// Loyalty Points queries
export async function getUserLoyaltyPoints(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(loyaltyPoints).where(eq(loyaltyPoints.userId, userId)).limit(1);
  return result[0];
}

export async function createUserLoyaltyPoints(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(loyaltyPoints).values({
    userId,
    totalPoints: 0,
    tier: "bronze",
  });
}

export async function updateLoyaltyTier(userId: number, points: number) {
  const db = await getDb();
  if (!db) return undefined;
  let tier = "bronze";
  if (points >= 1000) tier = "platinum";
  else if (points >= 500) tier = "gold";
  else if (points >= 100) tier = "silver";
  
  return await db.update(loyaltyPoints).set({ totalPoints: points, tier: tier as any }).where(eq(loyaltyPoints.userId, userId));
}

// Loyalty Transactions queries
export async function getUserLoyaltyTransactions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(loyaltyTransactions).where(eq(loyaltyTransactions.userId, userId)).orderBy(desc(loyaltyTransactions.createdAt));
}

export async function addLoyaltyTransaction(userId: number, points: number, type: string, description?: string, relatedOrderId?: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(loyaltyTransactions).values({
    userId,
    points,
    type: type as any,
    description,
    relatedOrderId,
  });
}


// Audio Content queries
export async function getUserAudioContent(userId: number, type?: string) {
  const db = await getDb();
  if (!db) return [];
  if (type) {
    return await db.select().from(audioContent).where(eq(audioContent.userId, userId) && eq(audioContent.type, type as any));
  }
  return await db.select().from(audioContent).where(eq(audioContent.userId, userId)).orderBy(desc(audioContent.createdAt));
}

export async function getDefaultAudioContent(userId: number, type: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(audioContent).where(eq(audioContent.userId, userId) && eq(audioContent.type, type as any) && eq(audioContent.isDefault, true)).limit(1);
  return result[0];
}

export async function createAudioContent(userId: number, title: string, type: string, audioUrl: string, fileKey: string, duration?: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(audioContent).values({
    userId,
    title,
    type: type as any,
    audioUrl,
    fileKey,
    duration,
    isActive: true,
    isDefault: false,
  });
}

export async function updateAudioContentDefault(userId: number, id: number, type: string) {
  const db = await getDb();
  if (!db) return undefined;
  // First, unset all defaults of this type
  await db.update(audioContent).set({ isDefault: false }).where(eq(audioContent.userId, userId) && eq(audioContent.type, type as any));
  // Then set the new default
  return await db.update(audioContent).set({ isDefault: true }).where(eq(audioContent.id, id));
}

export async function deleteAudioContent(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.delete(audioContent).where(eq(audioContent.id, id) && eq(audioContent.userId, userId));
}

// Admin Settings queries
export async function getAdminSettings(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(adminSettings).where(eq(adminSettings.userId, userId)).limit(1);
  return result[0];
}

export async function createAdminSettings(userId: number, adminPassword: string) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(adminSettings).values({
    userId,
    adminPassword,
    autoPlayEnabled: true,
    autoPlayVolume: "0.3",
  });
}

export async function updateAdminSettings(userId: number, updates: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.update(adminSettings).set(updates).where(eq(adminSettings.userId, userId));
}


// Design Templates queries
export async function getAllDesignTemplates() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(designTemplates).where(eq(designTemplates.isActive, true));
}

export async function getDesignTemplateById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(designTemplates).where(eq(designTemplates.id, id)).limit(1);
  return result[0];
}

// User Designs queries
export async function getUserDesigns(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(userDesigns).where(eq(userDesigns.userId, userId)).orderBy(desc(userDesigns.createdAt));
}

export async function createUserDesign(userId: number, name: string, description?: string, designData?: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(userDesigns).values({
    userId,
    name,
    description,
    designData,
    status: "draft",
  });
}

export async function deleteUserDesign(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.delete(userDesigns).where(eq(userDesigns.id, id) && eq(userDesigns.userId, userId));
}

// Video Jobs queries
export async function getUserVideoJobs(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(videoJobs).where(eq(videoJobs.userId, userId)).orderBy(desc(videoJobs.createdAt));
}

export async function createVideoJob(userId: number, title: string, script: string, coinsUsed?: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(videoJobs).values({
    userId,
    title,
    script,
    status: "pending",
    coinsUsed: (coinsUsed || 0).toString(),
  });
}

export async function getVideoJobStatus(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(videoJobs).where(eq(videoJobs.id, id)).limit(1);
  return result[0];
}

// Backup queries
export async function getUserBackups(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(backupHistory).where(eq(backupHistory.userId, userId)).orderBy(desc(backupHistory.createdAt));
}

export async function createBackup(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const backupUrl = `/backups/${userId}-${Date.now()}.zip`;
  return await db.insert(backupHistory).values({
    userId,
    backupType: "automatic",
    backupUrl,
    status: "completed",
  });
}

export async function restoreBackup(backupId: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const backup = await db.select().from(backupHistory).where(eq(backupHistory.id, backupId) && eq(backupHistory.userId, userId)).limit(1);
  return backup[0];
}

// Subscription History queries
export async function getUserSubscriptionHistory(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(subscriptionHistory).where(eq(subscriptionHistory.userId, userId)).orderBy(desc(subscriptionHistory.createdAt));
}

export async function createSubscriptionHistory(userId: number, planId: number, amount: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(subscriptionHistory).values({
    userId,
    planId,
    startDate: new Date(),
    amount: amount.toString(),
    status: "active",
  });
}

// Two-Factor Authentication queries
export async function getTwoFAStatus(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(twoFactorAuth).where(eq(twoFactorAuth.userId, userId)).limit(1);
  return result[0];
}

export async function enableTwoFA(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const secret = `SECRET_${userId}_${Date.now()}`;
  const backupCodes = Array.from({ length: 6 }, () => `CODE_${Math.random().toString(36).substring(2, 10).toUpperCase()}`);
  
  const existing = await getTwoFAStatus(userId);
  if (existing) {
    return await db.update(twoFactorAuth).set({
      isEnabled: true,
      secret,
      backupCodes: JSON.stringify(backupCodes),
    }).where(eq(twoFactorAuth.userId, userId));
  }
  
  return await db.insert(twoFactorAuth).values({
    userId,
    secret,
    isEnabled: true,
    backupCodes: JSON.stringify(backupCodes),
  });
}

export async function disableTwoFA(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.update(twoFactorAuth).set({ isEnabled: false }).where(eq(twoFactorAuth.userId, userId));
}

export async function verifyTwoFACode(userId: number, code: string) {
  const db = await getDb();
  if (!db) return false;
  const twoFA = await getTwoFAStatus(userId);
  if (!twoFA || !twoFA.isEnabled) return false;
  // In production, use a proper TOTP library to verify
  return code.length === 6;
}


