import { getSessionCookieOptions } from "./_core/cookies";
const COOKIE_NAME = "app_session_id";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // Services router
  services: router({
    list: publicProcedure.query(() => db.getAllServices()),
    getById: publicProcedure.input(z.number()).query(({ input }) => db.getServiceById(input)),
  }),

  // Projects router
  projects: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserProjects(ctx.user.id)),
  }),

  // Invoices router
  invoices: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserInvoices(ctx.user.id)),
  }),

  // Notifications router
  notifications: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserNotifications(ctx.user.id)),
  }),

  // Settings router
  settings: router({
    get: protectedProcedure.query(({ ctx }) => db.getUserSettings(ctx.user.id)),
  }),

  // Customers router
  customers: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserCustomers(ctx.user.id)),
  }),

  // Orders router
  orders: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserOrders(ctx.user.id)),
  }),

  // Subscription Plans router
  subscriptionPlans: router({
    list: publicProcedure.query(() => db.getAllSubscriptionPlans()),
  }),

  // Coins router
  coins: router({
    getBalance: protectedProcedure.query(async ({ ctx }) => {
      const coins = await db.getUserCoins(ctx.user.id);
      if (!coins) {
        await db.createUserCoins(ctx.user.id, 0);
        return { totalCoins: 0, earnedCoins: 0, spentCoins: 0 };
      }
      return coins;
    }),
    getTransactions: protectedProcedure.query(({ ctx }) => db.getUserCoinTransactions(ctx.user.id)),
    addTransaction: protectedProcedure
      .input(z.object({ amount: z.number(), type: z.string(), description: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        return await db.addCoinTransaction(ctx.user.id, input.amount, input.type, input.description);
      }),
  }),

  // Referrals router
  referrals: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserReferrals(ctx.user.id)),
    create: protectedProcedure.mutation(async ({ ctx }) => {
      const code = `REF${ctx.user.id}${Date.now().toString(36).toUpperCase()}`;
      const link = `${process.env.VITE_FRONTEND_URL || 'https://relaxfixup-jrbadqdh.manus.space'}?ref=${code}`;
      return await db.createReferral(ctx.user.id, code, link);
    }),
    getByCode: publicProcedure.input(z.string()).query(({ input }) => db.getReferralByCode(input)),
  }),

  // Loyalty router
  loyalty: router({
    getPoints: protectedProcedure.query(async ({ ctx }) => {
      const points = await db.getUserLoyaltyPoints(ctx.user.id);
      if (!points) {
        await db.createUserLoyaltyPoints(ctx.user.id);
        return { totalPoints: 0, tier: 'bronze' };
      }
      return points;
    }),
    getTransactions: protectedProcedure.query(({ ctx }) => db.getUserLoyaltyTransactions(ctx.user.id)),
    addPoints: protectedProcedure
      .input(z.object({ points: z.number(), type: z.string(), description: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const current = await db.getUserLoyaltyPoints(ctx.user.id);
        const newPoints = (current?.totalPoints || 0) + input.points;
        await db.updateLoyaltyTier(ctx.user.id, newPoints);
        return await db.addLoyaltyTransaction(ctx.user.id, input.points, input.type, input.description);
      }),
  }),

  // Audio Content router
  audio: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserAudioContent(ctx.user.id)),
    getByType: protectedProcedure.input(z.string()).query(({ ctx, input }) => db.getUserAudioContent(ctx.user.id, input)),
    getDefault: protectedProcedure.input(z.string()).query(({ ctx, input }) => db.getDefaultAudioContent(ctx.user.id, input)),
  }),

  // Admin Settings router
  admin: router({
    getSettings: protectedProcedure.query(async ({ ctx }) => {
      const settings = await db.getAdminSettings(ctx.user.id);
      if (!settings && ctx.user.role === 'admin') {
        await db.createAdminSettings(ctx.user.id, 'admin123');
        return await db.getAdminSettings(ctx.user.id);
      }
      return settings;
    }),
  }),

  // Design Templates router
  designTemplates: router({
    list: publicProcedure.query(() => db.getAllDesignTemplates()),
  }),

  // User Designs router
  designs: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserDesigns(ctx.user.id)),
    create: protectedProcedure
      .input(z.object({ name: z.string(), description: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        return await db.createUserDesign(ctx.user.id, input.name, input.description);
      }),
  }),

  // Video Generation router
  videos: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserVideoJobs(ctx.user.id)),
    create: protectedProcedure
      .input(z.object({ title: z.string(), script: z.string() }))
      .mutation(async ({ ctx, input }) => {
        return await db.createVideoJob(ctx.user.id, input.title, input.script);
      }),
  }),

  // Backup router
  backups: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserBackups(ctx.user.id)),
    create: protectedProcedure.mutation(async ({ ctx }) => {
      return await db.createBackup(ctx.user.id);
    }),
  }),

  // Subscription History router
  subscriptionHistory: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserSubscriptionHistory(ctx.user.id)),
  }),

  // Two-Factor Authentication router
  twoFA: router({
    getStatus: protectedProcedure.query(({ ctx }) => db.getTwoFAStatus(ctx.user.id)),
    enable: protectedProcedure.mutation(async ({ ctx }) => {
      return await db.enableTwoFA(ctx.user.id);
    }),
  }),
});

export type AppRouter = typeof appRouter;
